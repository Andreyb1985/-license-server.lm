from __future__ import annotations

import json
import hashlib
import os
import re
import shutil
import subprocess
import sys
import threading
import webbrowser
from copy import deepcopy
from datetime import datetime
from pathlib import Path

from ui_web.bridge_compat import QObject, Signal, Slot, QWidget
from openpyxl import load_workbook

from core.config import (
    BASE_DIR,
    COMPANIES_DIR,
    GESOB_DIR,
    LEGACY_GESOB_DIR,
    LEGACY_SETTINGS_DIR,
    SETTINGS_DIR,
    company_output_dir,
    delete_company_smtp_secret,
    get_company_email_excel_file,
    get_company_name,
    load_settings,
    save_settings,
)
from core.license_manager import LicenseManager
from ui_web.report_history import ReportHistoryStore
from ui_web.updater import UpdateService
from ui_web.version import APP_BUILD, APP_VERSION
from ui_web.workflow_sessions import WorkflowSessionStore


def _open_target(target: str | Path) -> bool:
    value = str(target)
    try:
        if re.match(r"^[a-z][a-z0-9+.-]*:", value, flags=re.IGNORECASE):
            return bool(webbrowser.open(value))
        path = str(Path(value).expanduser().resolve())
        if sys.platform == "darwin":
            subprocess.Popen(["open", path], close_fds=True)
        elif sys.platform == "win32":
            os.startfile(path)  # type: ignore[attr-defined]
        else:
            subprocess.Popen(["xdg-open", path], close_fds=True)
        return True
    except Exception:
        return False


class ProcessingWorker(QObject):
    progress = Signal(str)
    finished = Signal(dict)
    error = Signal(str)

    def __init__(
        self,
        mode: str,
        pdf_input: Path,
        excel_path: Path,
        settings: dict,
        dry_run: bool,
        selected_persnr: set[str] | None = None,
    ) -> None:
        super().__init__()
        self.mode = mode
        self.pdf_input = pdf_input
        self.excel_path = excel_path
        self.settings = settings
        self.dry_run = dry_run
        self.selected_persnr = selected_persnr

    @Slot()
    def run(self) -> None:
        try:
            from core.jobs import run_main_job

            result = run_main_job(
                mode=self.mode,
                pdf_input=self.pdf_input,
                excel_path=self.excel_path,
                settings=self.settings,
                dry_run=self.dry_run,
                selected_persnr=self.selected_persnr,
                progress_cb=self.progress.emit,
            )
            self.finished.emit(result)
        except Exception as exc:
            self.error.emit(self._friendly_error(exc))

    @staticmethod
    def _friendly_error(exc: Exception) -> str:
        message = str(exc)
        if "Directory 'static/' does not exist" in message:
            return (
                "PDF Engine ist falsch installiert: Python lädt das Paket 'fitz' statt 'PyMuPDF'. "
                "Bitte im aktiven venv 'fitz' entfernen und 'PyMuPDF' installieren."
            )
        return message


class MassMessageWorker(QObject):
    progress = Signal(str)
    finished = Signal(dict)
    error = Signal(str)

    def __init__(
        self,
        settings: dict,
        company_id: str,
        subject_template: str,
        body_template: str,
        recipients: list[dict],
    ) -> None:
        super().__init__()
        self.settings = settings
        self.company_id = company_id
        self.subject_template = subject_template
        self.body_template = body_template
        self.recipients = recipients

    @Slot()
    def run(self) -> None:
        try:
            from core.jobs import run_mass_message_job

            result = run_mass_message_job(
                settings=self.settings,
                company_id=self.company_id,
                subject_template=self.subject_template,
                body_template=self.body_template,
                recipients=self.recipients,
                progress_cb=self.progress.emit,
            )
            self.finished.emit(result)
        except Exception as exc:
            self.error.emit(ProcessingWorker._friendly_error(exc))


class UpdateWorker(QObject):
    progress = Signal(dict)
    finished = Signal(dict)

    def __init__(self, service: UpdateService, action: str) -> None:
        super().__init__()
        self.service = service
        self.action = action

    @Slot()
    def run(self) -> None:
        try:
            if self.action == "check":
                state = self.service.check()
            elif self.action == "download":
                state = self.service.download(self.progress.emit)
            else:
                state = {
                    **self.service.current_state(),
                    "status": "error",
                    "message": "Unbekannte Update-Aktion.",
                }
        except Exception as exc:  # defensive boundary for the Qt worker
            state = {
                **self.service.current_state(),
                "status": "error",
                "message": f"Update fehlgeschlagen: {exc}",
            }
        self.finished.emit(state)


class WebBridge(QObject):
    """Bridge for the WebEngine UI.

    Keep this layer thin: it may persist UI input paths and invoke existing
    core jobs, but business rules stay in core modules.
    """

    pageChanged = Signal(str)
    processingStateChanged = Signal(str)
    processingProgress = Signal(str)
    processingFinished = Signal(str)
    processingError = Signal(str)
    shippingStateChanged = Signal(str)
    shippingProgress = Signal(str)
    shippingFinished = Signal(str)
    shippingError = Signal(str)
    massMessageStateChanged = Signal(str)
    massMessageProgress = Signal(str)
    massMessageFinished = Signal(str)
    massMessageError = Signal(str)
    updateStateChanged = Signal(str)
    updateProgress = Signal(str)

    REPORT_FILES = {
        "audit": "audit_check.xlsx",
        "missing": "ohne_email_gesamt.pdf",
        "send": "send_report.xlsx",
    }
    REPORT_INDEX_PATH = GESOB_DIR / "lohnmail_reports_index.json"
    REPORT_HISTORY_PATH = SETTINGS_DIR / "lohnmail_history.sqlite3"

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._dialog_parent = parent
        self.worker_thread: threading.Thread | None = None
        self.worker: ProcessingWorker | MassMessageWorker | None = None
        self._processing_running = False
        self._processing_status = self._idle_processing_status()
        self._processing_company_id = ""
        self._processing_input_signature: tuple[str, str, str, str] | None = None
        self._validation_state = self._empty_validation_state()
        self._validation_company_id = ""
        self._validation_input_signature: tuple[str, str, str, str] | None = None
        self._shipping_running = False
        self._shipping_status = self._idle_shipping_status()
        self._shipping_company_id = ""
        self._shipping_input_signature: tuple[str, ...] | None = None
        self._shipping_rows: list[dict] = []
        self._shipping_source_rows: list[dict] = []
        self._mass_message_running = False
        self._mass_message_status = self._idle_mass_message_status()
        self._mass_message_preview = self._empty_mass_message_preview()
        self._license_manager = LicenseManager(load_settings())
        self._update_service = UpdateService()
        self._update_service.recover_interrupted_state()
        self._update_thread: threading.Thread | None = None
        self._update_worker: UpdateWorker | None = None
        legacy_history = LEGACY_SETTINGS_DIR / "lohnmail_history.sqlite3"
        if not self.REPORT_HISTORY_PATH.exists() and legacy_history.is_file():
            self.REPORT_HISTORY_PATH.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(legacy_history, self.REPORT_HISTORY_PATH)
        try:
            self._report_history: ReportHistoryStore | None = ReportHistoryStore(self.REPORT_HISTORY_PATH)
        except Exception:
            self._report_history = None
        self._workflow_sessions = WorkflowSessionStore(SETTINGS_DIR / "workflow_sessions.json")
        self._restore_workflow_session(load_settings())

    @Slot(str)
    def navigate(self, page: str) -> None:
        self.pageChanged.emit(page)

    @Slot(str, result=str)
    def openProductContact(self, action: str) -> str:
        contacts = {
            "website": ("https://lohn-mail.de", "Website wurde geöffnet."),
            "email": ("mailto:support@lohn-mail.de", "E-Mail-Programm wurde geöffnet."),
        }
        contact = contacts.get(str(action or "").strip().lower())
        if not contact:
            return json.dumps({"ok": False, "message": "Unbekannter Produktkontakt."}, ensure_ascii=False)
        url, success_message = contact
        opened = _open_target(url)
        return json.dumps(
            {
                "ok": bool(opened),
                "message": success_message if opened else "Kontakt konnte nicht geöffnet werden.",
            },
            ensure_ascii=False,
        )

    @Slot(result=str)
    def appVersion(self) -> str:
        return APP_VERSION

    @Slot(result=str)
    def appBuild(self) -> str:
        return APP_BUILD

    @Slot(result=str)
    def getUpdateState(self) -> str:
        return json.dumps(self._update_service.current_state(), ensure_ascii=False)

    @Slot(str, result=str)
    def setUpdatePreferences(self, payload: str) -> str:
        try:
            data = json.loads(payload or "{}")
            if not isinstance(data, dict):
                raise ValueError("Update-Einstellungen sind ungültig.")
            auto_check = data.get("auto_check")
            install_on_exit = data.get("install_on_exit")
            state = self._update_service.set_preferences(
                auto_check=auto_check if isinstance(auto_check, bool) else None,
                install_on_exit=install_on_exit if isinstance(install_on_exit, bool) else None,
            )
            self.updateStateChanged.emit(json.dumps(state, ensure_ascii=False))
            return json.dumps({"ok": True, **state}, ensure_ascii=False)
        except Exception as exc:
            return json.dumps({"ok": False, "message": str(exc)}, ensure_ascii=False)

    @Slot(result=str)
    def checkForUpdates(self) -> str:
        return json.dumps(self._start_update_action("check"), ensure_ascii=False)

    @Slot(result=str)
    def downloadUpdate(self) -> str:
        return json.dumps(self._start_update_action("download"), ensure_ascii=False)

    @Slot(result=str)
    def installUpdateOnExit(self) -> str:
        state = self._update_service.install_on_exit()
        return json.dumps(state, ensure_ascii=False)

    def _start_update_action(self, action: str) -> dict:
        self._update_service.begin(action)
        state = self._update_service.check() if action == "check" else self._update_service.download(
            progress=self._on_update_progress
        )
        self._on_update_finished(state)
        return {"ok": True, **state}

    @Slot(dict)
    def _on_update_progress(self, state: dict) -> None:
        self.updateProgress.emit(json.dumps(state, ensure_ascii=False))

    @Slot(dict)
    def _on_update_finished(self, state: dict) -> None:
        self.updateStateChanged.emit(json.dumps(state, ensure_ascii=False))

    @Slot(result=str)
    def getDashboardState(self) -> str:
        settings = load_settings()
        ui_settings = settings.get("ui", {})
        effective_settings = self._settings_with_company_mail(settings)
        smtp_settings = effective_settings.get("smtp", {})
        license_payload = self._license_payload(settings, refresh=True)
        license_active = bool(license_payload.get("active"))

        mail_mode = str(effective_settings.get("mail_mode", "smtp") or "smtp").strip().lower()
        smtp_server = str(smtp_settings.get("server", "") or "").strip()
        smtp_from = str(smtp_settings.get("from_email", "") or smtp_settings.get("username", "") or "").strip()
        mail_configured = bool(smtp_from and (mail_mode == "outlook" or smtp_server))
        mail_label = "Outlook Classic" if mail_configured and mail_mode == "outlook" else (
            "Konfiguriert" if mail_configured else "Nicht konfiguriert"
        )

        reports_payload = self._reports_payload(settings)
        reports = self._current_reports_state(settings, reports_payload)
        runs = self._dashboard_runs(reports_payload.get("records", []))
        last_run = runs[0] if runs else None
        metrics = {**self._empty_report_metrics(), **((last_run or {}).get("metrics", {}))}

        active_company_id = self._active_company_id(settings)
        processing_matches = bool(
            active_company_id
            and self._processing_company_id == active_company_id
            and self._processing_input_signature == self._input_signature(settings)
        )
        processing_status = self._processing_status if processing_matches else self._idle_processing_status()
        processing_payload = self._processing_payload(settings)
        inputs = processing_payload.get("inputs", {})
        pdf_ready = bool(inputs.get("pdf", {}).get("valid"))
        excel_ready = bool(inputs.get("excel", {}).get("valid"))
        output_ready = bool(inputs.get("output", {}).get("valid"))
        has_company = bool(active_company_id)
        system_ready = bool(has_company and pdf_ready and excel_ready and output_ready and mail_configured and license_active)
        payload = {
            "version": self.appVersion(),
            "company": get_company_name(settings),
            "license": license_payload,
            "mail": {
                "mode": mail_mode,
                "configured": mail_configured,
                "label": mail_label,
            },
            "paths": {
                "last_pdf_dir": str(ui_settings.get("last_pdf_dir", "") or ""),
                "last_excel_file": str(get_company_email_excel_file(settings, active_company_id) or ""),
                "output_dir": str(company_output_dir(settings, active_company_id)),
            },
            "metrics": {
                "employees": int(metrics.get("employees", 0) or metrics.get("processed", 0) or 0),
                "sent": int(metrics.get("sent", 0) or 0),
                "missing_email": int(metrics.get("missing_email", 0) or 0),
                "errors": int(metrics.get("errors", 0) or metrics.get("failed", 0) or 0),
            },
            "system": {
                "ready": system_ready,
                "processing": "Fehler" if processing_status.get("failed") else (
                    "Läuft" if processing_status.get("running") else "Bereit"
                ),
                "pdf": "Bereit" if pdf_ready else "Offen",
                "excel": "Bereit" if excel_ready else "Offen",
                "mail": "Bereit" if mail_configured else "Offen",
                "license": "Bereit" if license_active else "Offen",
                "filesystem": "Bereit" if output_ready else "Offen",
            },
            "reports": reports,
            "last_run": last_run,
            "activity": runs[:4],
        }
        return json.dumps(payload, ensure_ascii=False)

    @Slot(result=str)
    def startNewRun(self) -> str:
        if self._workflow_running():
            return json.dumps(
                {"ok": False, "message": "Ein Vorgang läuft bereits und kann nicht zurückgesetzt werden."},
                ensure_ascii=False,
            )
        settings = load_settings()
        self._workflow_sessions.delete(self._active_company_id(settings))
        self._reset_workflow_state()
        state = self._processing_payload(settings)
        serialized_state = json.dumps(state, ensure_ascii=False)
        self.processingStateChanged.emit(serialized_state)
        return json.dumps(
            {"ok": True, "message": "Neuer Lauf wurde vorbereitet.", "state": state},
            ensure_ascii=False,
        )

    @Slot(result=str)
    def getProcessingState(self) -> str:
        settings = load_settings()
        return json.dumps(self._processing_payload(settings), ensure_ascii=False)

    @Slot(result=str)
    def getValidationState(self) -> str:
        settings = load_settings()
        if (
            self._validation_company_id != self._active_company_id(settings)
            or self._validation_input_signature != self._input_signature(settings)
        ):
            return json.dumps(self._empty_validation_state(), ensure_ascii=False)
        return json.dumps(self._validation_state, ensure_ascii=False)

    @Slot(result=str)
    def getShippingState(self) -> str:
        return json.dumps(self._shipping_payload(load_settings()), ensure_ascii=False)

    @Slot(result=str)
    def getReportsState(self) -> str:
        return json.dumps(self._reports_payload(load_settings()), ensure_ascii=False)

    @Slot(result=str)
    def getMassMessageState(self) -> str:
        return json.dumps(self._mass_message_payload(self._settings_with_company_mail(load_settings())), ensure_ascii=False)

    @Slot(result=str)
    def getCompanyState(self) -> str:
        return json.dumps(self._company_payload(load_settings()), ensure_ascii=False)

    @Slot(result=str)
    def getLicenseState(self) -> str:
        return json.dumps(self._license_payload(load_settings(), refresh=True), ensure_ascii=False)

    @Slot(result=str)
    def checkLicense(self) -> str:
        manager = LicenseManager(load_settings())
        state = manager.refresh(force=True, start_trial=True)
        return json.dumps(self._license_payload(load_settings(), state=state), ensure_ascii=False)

    @Slot(result=str)
    def buyLicense(self) -> str:
        settings = load_settings()
        manager = LicenseManager(settings)
        try:
            licensee = self._licensee_settings(settings)
            if not licensee.get("name") or not licensee.get("email"):
                raise ValueError("Bitte zuerst Lizenznehmer mit Firma und E-Mail speichern.")
            response = manager.purchase_session(
                email=licensee.get("email", ""),
                company_name=licensee.get("name", ""),
                address=licensee.get("address", ""),
                company_number=licensee.get("company_number", ""),
            )
            if response.get("already_active"):
                state = manager.load_state()
                return json.dumps(
                    {
                        "ok": True,
                        "message": response.get("message", "Für diese Installation ist bereits eine aktive Lizenz vorhanden."),
                        "state": self._license_payload(settings, state=state),
                    },
                    ensure_ascii=False,
                )
            url = str(response.get("url") or "")
            if not url:
                raise ValueError("Stripe Checkout URL konnte nicht erstellt werden.")
            _open_target(url)
            state = manager.load_state()
            return json.dumps(
                {"ok": True, "message": "Stripe Checkout wurde geöffnet.", "state": self._license_payload(settings, state=state)},
                ensure_ascii=False,
            )
        except Exception as exc:
            return json.dumps({"ok": False, "message": str(exc), "state": self._license_payload(settings)}, ensure_ascii=False)

    @Slot(result=str)
    def buyLicenseByInvoice(self) -> str:
        settings = load_settings()
        manager = LicenseManager(settings)
        try:
            licensee = self._licensee_settings(settings)
            if not licensee.get("name") or not licensee.get("email"):
                raise ValueError("Bitte zuerst Lizenznehmer mit Firma und E-Mail speichern.")
            if not licensee.get("address"):
                raise ValueError("Für den Rechnungskauf ist eine vollständige Rechnungsanschrift erforderlich.")
            response = manager.purchase_invoice_subscription(
                email=licensee.get("email", ""),
                company_name=licensee.get("name", ""),
                address=licensee.get("address", ""),
                company_number=licensee.get("company_number", ""),
            )
            if response.get("already_active"):
                state = manager.load_state()
                return json.dumps(
                    {
                        "ok": True,
                        "message": response.get(
                            "message",
                            "Für diese Installation ist bereits eine aktive oder offene Subscription vorhanden.",
                        ),
                        "state": self._license_payload(settings, state=state),
                    },
                    ensure_ascii=False,
                )
            invoice_url = str(response.get("invoice_url") or "")
            if invoice_url:
                _open_target(invoice_url)
            state = manager.refresh(force=True, start_trial=False)
            return json.dumps(
                {
                    "ok": True,
                    "message": response.get(
                        "message",
                        "Rechnungszahlung wurde eingerichtet. Die Rechnung wird per E-Mail versendet.",
                    ),
                    "state": self._license_payload(settings, state=state),
                },
                ensure_ascii=False,
            )
        except Exception as exc:
            return json.dumps(
                {"ok": False, "message": str(exc), "state": self._license_payload(settings)},
                ensure_ascii=False,
            )

    @Slot(str, result=str)
    def saveLicenseeState(self, payload: str) -> str:
        try:
            data = json.loads(payload or "{}")
            if not isinstance(data, dict):
                raise ValueError("Ungültige Lizenznehmerdaten.")
            settings = load_settings()
            licensee = settings.setdefault("licensee", {})
            for key in ["name", "email", "address", "company_number"]:
                if key in data:
                    licensee[key] = str(data.get(key) or "").strip()
            if licensee.get("email") and not re.match(r"^[^\s@]+@[^\s@]+\.[^\s@]+$", str(licensee.get("email"))):
                raise ValueError("Bitte eine gültige E-Mail-Adresse eingeben.")
            save_settings(settings)
            settings = load_settings()
            manager = LicenseManager(settings)
            license_state = manager.load_state()
            if license_state.get("license_key"):
                try:
                    license_state = manager.update_licensee(
                        name=str(licensee.get("name") or ""),
                        email=str(licensee.get("email") or ""),
                        address=str(licensee.get("address") or ""),
                        company_number=str(licensee.get("company_number") or ""),
                    )
                except Exception as exc:
                    return json.dumps(
                        {
                            "ok": False,
                            "local_saved": True,
                            "message": f"Lokal gespeichert, aber nicht mit dem Lizenzserver synchronisiert: {exc}",
                            "state": self._license_payload(settings, state=license_state),
                        },
                        ensure_ascii=False,
                    )
            return json.dumps(
                {
                    "ok": True,
                    "message": "Lizenznehmer wurde gespeichert und mit dem Lizenzserver synchronisiert."
                    if license_state.get("license_key")
                    else "Lizenznehmer wurde lokal gespeichert.",
                    "state": self._license_payload(settings, state=license_state),
                },
                ensure_ascii=False,
            )
        except Exception as exc:
            return json.dumps(
                {"ok": False, "message": f"Lizenznehmer konnte nicht gespeichert werden: {exc}", "state": self._license_payload(load_settings())},
                ensure_ascii=False,
            )

    @Slot(result=str)
    def openCustomerPortal(self) -> str:
        settings = load_settings()
        manager = LicenseManager(settings)
        try:
            url = manager.portal_url()
            if not url:
                raise ValueError("Kundenportal URL konnte nicht erstellt werden.")
            _open_target(url)
            return json.dumps({"ok": True, "message": "Stripe Kundenportal wurde geöffnet.", "state": self._license_payload(settings)}, ensure_ascii=False)
        except Exception as exc:
            return json.dumps({"ok": False, "message": str(exc), "state": self._license_payload(settings)}, ensure_ascii=False)

    @Slot(str, result=str)
    def activateLicenseKey(self, license_key: str) -> str:
        settings = load_settings()
        manager = LicenseManager(settings)
        try:
            state = manager.activate(str(license_key or "").strip())
            settings.setdefault("license", {})["key"] = str(state.get("license_key", "") or "")
            settings["license"]["status"] = str(state.get("status", "") or "")
            save_settings(settings)
            return json.dumps({"ok": True, "message": state.get("last_message", "Lizenz wurde aktiviert."), "state": self._license_payload(load_settings(), state=state)}, ensure_ascii=False)
        except Exception as exc:
            return json.dumps({"ok": False, "message": str(exc), "state": self._license_payload(settings)}, ensure_ascii=False)

    @Slot(result=str)
    def promptActivateLicenseKey(self) -> str:
        return json.dumps(
            {
                "ok": False,
                "needs_input": True,
                "message": "Bitte einen Lizenzschlüssel eingeben.",
                "state": self._license_payload(load_settings()),
            },
            ensure_ascii=False,
        )

    @Slot(result=str)
    def deactivateLicense(self) -> str:
        settings = load_settings()
        manager = LicenseManager(settings)
        try:
            state = manager.deactivate()
            settings.setdefault("license", {})["key"] = ""
            settings["license"]["status"] = str(state.get("status", "") or "unregistered")
            save_settings(settings)
            return json.dumps({"ok": True, "message": state.get("last_message", "Lizenz wurde deaktiviert."), "state": self._license_payload(load_settings(), state=state)}, ensure_ascii=False)
        except Exception as exc:
            return json.dumps({"ok": False, "message": str(exc), "state": self._license_payload(settings)}, ensure_ascii=False)

    @Slot(result=str)
    def getSettingsState(self) -> str:
        return json.dumps(self._settings_payload(load_settings()), ensure_ascii=False)

    @Slot(str, result=str)
    def saveCompanyState(self, payload: str) -> str:
        try:
            data = json.loads(payload or "{}")
            if not isinstance(data, dict):
                raise ValueError("Ungültige Mandantendaten.")

            settings = load_settings()
            selected_company_id = str(settings.get("selected_company_id", "") or "").strip()
            company = self._selected_company(settings)
            if not selected_company_id or company is None:
                raise ValueError("Bitte zuerst ein Unternehmen auswählen.")

            name = str(data.get("name", "") or "").strip()
            if not name:
                raise ValueError("Bitte Unternehmensname eingeben.")
            company["name"] = name

            mail_scope = str(data.get("mail_scope", "global") or "global").strip().lower()
            if mail_scope not in {"global", "custom"}:
                mail_scope = "global"
            mail_settings = company.setdefault("mail_settings", {})
            mail_settings["scope"] = mail_scope

            smtp_data = data.get("smtp") if isinstance(data.get("smtp"), dict) else {}
            smtp = mail_settings.setdefault("smtp", {})
            for key in ["server", "security", "username", "from_email", "from_name"]:
                if key in smtp_data:
                    smtp[key] = str(smtp_data.get(key) or "").strip()
            if "port" in smtp_data:
                smtp["port"] = max(1, min(65535, int(smtp_data.get("port") or 587)))
            if "timeout_sec" in smtp_data:
                smtp["timeout_sec"] = max(5, min(300, int(smtp_data.get("timeout_sec") or 30)))
            if "password" in smtp_data and str(smtp_data.get("password") or ""):
                smtp["password"] = str(smtp_data.get("password") or "")

            if mail_scope == "custom" and any(
                str(smtp.get(key, "") or "").strip()
                for key in ("server", "username", "from_email")
            ):
                from core.mailer import validate_sender_email

                validate_sender_email(str(smtp.get("from_email") or smtp.get("username") or ""))

            save_settings(settings)
            settings = load_settings()
            self.processingStateChanged.emit(json.dumps(self._processing_payload(settings), ensure_ascii=False))
            self.shippingStateChanged.emit(json.dumps(self._shipping_payload(settings), ensure_ascii=False))
            self.massMessageStateChanged.emit(json.dumps(self._mass_message_payload(self._settings_with_company_mail(settings)), ensure_ascii=False))
            return json.dumps(
                {
                    "ok": True,
                    "message": "Mandant wurde gespeichert.",
                    "state": self._company_payload(settings),
                },
                ensure_ascii=False,
            )
        except Exception as exc:
            return json.dumps(
                {
                    "ok": False,
                    "message": f"Mandant konnte nicht gespeichert werden: {exc}",
                    "state": self._company_payload(load_settings()),
                },
                ensure_ascii=False,
            )

    @Slot(result=str)
    def getOutlookAccounts(self) -> str:
        try:
            from core.mailer import list_outlook_accounts

            return json.dumps({"ok": True, "accounts": list_outlook_accounts()}, ensure_ascii=False)
        except Exception as exc:
            return json.dumps({"ok": False, "message": str(exc), "accounts": []}, ensure_ascii=False)

    @Slot(result=str)
    def testMailConnection(self) -> str:
        try:
            settings = load_settings()
            mail_mode = str(settings.get("mail_mode", "smtp") or "smtp").strip().lower()
            smtp_settings = settings.get("smtp", {})
            if mail_mode == "outlook":
                from core.mailer import test_outlook_connection

                test_outlook_connection(str(smtp_settings.get("from_email", "") or "").strip())
                return json.dumps({"ok": True, "message": "Outlook-Classic-Verbindung ist bereit."}, ensure_ascii=False)

            from core.mailer import test_smtp_connection

            test_smtp_connection(smtp_settings)
            return json.dumps({"ok": True, "message": "SMTP-Verbindung ist bereit."}, ensure_ascii=False)
        except Exception as exc:
            return json.dumps({"ok": False, "message": str(exc)}, ensure_ascii=False)

    @Slot(result=str)
    def testCompanyMailConnection(self) -> str:
        try:
            settings = self._settings_with_company_mail(load_settings())
            mail_mode = str(settings.get("mail_mode", "smtp") or "smtp").strip().lower()
            smtp_settings = settings.get("smtp", {})
            if mail_mode == "outlook":
                from core.mailer import test_outlook_connection

                test_outlook_connection(str(smtp_settings.get("from_email", "") or "").strip())
                return json.dumps({"ok": True, "message": "Mandant-Outlook-Classic-Verbindung ist bereit."}, ensure_ascii=False)

            from core.mailer import test_smtp_connection

            test_smtp_connection(smtp_settings)
            return json.dumps({"ok": True, "message": "Mandant-SMTP-Verbindung ist bereit."}, ensure_ascii=False)
        except Exception as exc:
            return json.dumps({"ok": False, "message": str(exc)}, ensure_ascii=False)

    @Slot(str, str, result=str)
    def previewMassMessage(self, subject: str, body: str) -> str:
        settings = self._settings_with_company_mail(load_settings())
        try:
            preview = self._build_mass_message_preview(settings, subject, body)
            self._mass_message_preview = preview
            self._mass_message_status = {
                **self._idle_mass_message_status(),
                "preview_ready": True,
                "message": f"{preview['total_count']} Empfänger geladen. Vorschau ist bereit.",
            }
        except Exception as exc:
            self._mass_message_preview = self._empty_mass_message_preview()
            self._mass_message_status = {
                **self._idle_mass_message_status(),
                "failed": True,
                "message": f"Vorschau fehlgeschlagen: {exc}",
            }
        serialized = json.dumps(self._mass_message_payload(settings), ensure_ascii=False)
        self.massMessageStateChanged.emit(serialized)
        return serialized

    @Slot(str, str, result=str)
    def startMassMessage(self, subject: str, body: str) -> str:
        if self._processing_running or self._shipping_running or self._mass_message_running:
            return self._emit_mass_message_payload(self._settings_with_company_mail(load_settings()))

        settings = self._settings_with_company_mail(load_settings())
        allowed, license_state = LicenseManager(settings).require_action("shipping")
        if not allowed:
            self._mass_message_status = {
                **self._idle_mass_message_status(),
                "failed": True,
                "message": license_state.get("last_message", "Bitte aktivieren Sie eine gültige Lizenz."),
            }
            return self._emit_mass_message_payload(settings)

        try:
            preview = self._build_mass_message_preview(settings, subject, body)
        except Exception as exc:
            self._mass_message_status = {
                **self._idle_mass_message_status(),
                "failed": True,
                "message": f"Nachricht kann nicht gestartet werden: {exc}",
            }
            return self._emit_mass_message_payload(settings)

        self._mass_message_preview = preview
        self._mass_message_running = True
        self._mass_message_status = {
            **self._idle_mass_message_status(),
            "running": True,
            "preview_ready": True,
            "current_step": "Nachricht wird gesendet",
            "progress": 8,
            "total_count": int(preview.get("total_count", 0) or 0),
            "message": "Nachricht-Versand wurde gestartet.",
        }
        self._emit_mass_message_payload(settings)

        request_settings = deepcopy(settings)
        request_settings["selected_company_id"] = preview["company_id"]

        def run_mass_message() -> None:
            try:
                from core.jobs import run_mass_message_job

                result = run_mass_message_job(
                    settings=request_settings,
                    company_id=preview["company_id"],
                    subject_template=subject,
                    body_template=body,
                    recipients=preview["recipients"],
                    progress_cb=self._on_mass_message_progress,
                )
                self._on_mass_message_finished(result)
            except Exception as exc:
                self._on_mass_message_error(str(exc))

        self.worker_thread = threading.Thread(
            target=run_mass_message,
            name="lohnmail-pywebview-mass-message",
            daemon=True,
        )
        self.worker_thread.start()

        return json.dumps(self._mass_message_payload(settings), ensure_ascii=False)

    @Slot(str, result=str)
    def saveSettingsState(self, payload: str) -> str:
        try:
            data = json.loads(payload or "{}")
            if not isinstance(data, dict):
                raise ValueError("Ungültige Einstellungen.")
            settings = load_settings()
            smtp = settings.setdefault("smtp", {})
            mail_text = settings.setdefault("mail_text", {})
            pdf_password = settings.setdefault("pdf_password", {})
            period = settings.setdefault("period", {})
            ui_settings = settings.setdefault("ui", {})
            notifications = settings.setdefault("notifications", {})
            licensee = settings.setdefault("licensee", {})

            if "mail_mode" in data:
                settings["mail_mode"] = str(data.get("mail_mode") or "smtp").strip() or "smtp"

            smtp_data = data.get("smtp") if isinstance(data.get("smtp"), dict) else {}
            for key in ["server", "security", "username", "from_email", "from_name"]:
                if key in smtp_data:
                    smtp[key] = str(smtp_data.get(key) or "").strip()
            if "port" in smtp_data:
                smtp["port"] = max(1, min(65535, int(smtp_data.get("port") or 587)))
            if "timeout_sec" in smtp_data:
                smtp["timeout_sec"] = max(5, min(300, int(smtp_data.get("timeout_sec") or 30)))
            if "password" in smtp_data and str(smtp_data.get("password") or ""):
                smtp["password"] = str(smtp_data.get("password") or "")

            if any(
                str(smtp.get(key, "") or "").strip()
                for key in ("server", "username", "from_email")
            ):
                from core.mailer import validate_sender_email

                validate_sender_email(str(smtp.get("from_email") or smtp.get("username") or ""))

            text_data = data.get("mail_text") if isinstance(data.get("mail_text"), dict) else {}
            for key in ["subject", "body", "body_html"]:
                if key in text_data:
                    mail_text[key] = str(text_data.get(key) or "")

            password_data = data.get("pdf_password") if isinstance(data.get("pdf_password"), dict) else {}
            if "enabled" in password_data:
                pdf_password["enabled"] = bool(password_data.get("enabled"))
            if "source" in password_data:
                password_source = str(password_data.get("source") or "persnr").strip().lower()
                pdf_password["source"] = (
                    password_source if password_source in {"persnr", "birth_date"} else "persnr"
                )
            for key in ["prefix", "suffix"]:
                if key in password_data:
                    pdf_password[key] = str(password_data.get(key) or "")

            period_data = data.get("period") if isinstance(data.get("period"), dict) else {}
            if "mode" in period_data:
                period["mode"] = str(period_data.get("mode") or "automatic_current_month")
            if "month" in period_data:
                period["month"] = max(1, min(12, int(period_data.get("month") or 1)))
            if "year" in period_data:
                period["year"] = max(2020, min(2100, int(period_data.get("year") or datetime.now().year)))

            ui_data = data.get("ui") if isinstance(data.get("ui"), dict) else {}
            for key in ["dry_run_default", "remember_last_paths"]:
                if key in ui_data:
                    ui_settings[key] = bool(ui_data.get(key))

            notification_data = data.get("notifications") if isinstance(data.get("notifications"), dict) else {}
            for key in [
                "show_badge",
                "workflow_warnings",
                "validation_warnings",
                "processing_errors",
                "delivery_events",
                "auto_open_on_start",
            ]:
                if key in notification_data:
                    notifications[key] = bool(notification_data.get(key))

            licensee_data = data.get("licensee") if isinstance(data.get("licensee"), dict) else {}
            for key in ["name", "email", "address", "company_number"]:
                if key in licensee_data:
                    licensee[key] = str(licensee_data.get(key) or "").strip()

            save_settings(settings)
            settings = load_settings()
            self.processingStateChanged.emit(json.dumps(self._processing_payload(settings), ensure_ascii=False))
            self.shippingStateChanged.emit(json.dumps(self._shipping_payload(settings), ensure_ascii=False))
            return json.dumps({"ok": True, "message": "Einstellungen wurden gespeichert.", "state": self._settings_payload(settings)}, ensure_ascii=False)
        except Exception as exc:
            return json.dumps({"ok": False, "message": f"Einstellungen konnten nicht gespeichert werden: {exc}"}, ensure_ascii=False)

    @Slot(str, result=str)
    def selectCompany(self, company_id: str) -> str:
        settings = load_settings()
        requested_id = str(company_id or "").strip()
        known_ids = {
            str(company.get("id", "") or "").strip()
            for company in settings.get("companies", [])
            if isinstance(company, dict)
        }
        current_id = self._active_company_id(settings)
        if requested_id not in known_ids:
            payload = self._company_payload(settings)
            payload.update({"ok": False, "message": "Der ausgewählte Mandant wurde nicht gefunden."})
            return json.dumps(payload, ensure_ascii=False)
        if requested_id != current_id and self._workflow_running():
            payload = self._company_payload(settings)
            payload.update(
                {
                    "ok": False,
                    "message": "Mandant kann während einer laufenden Prüfung oder eines Versands nicht gewechselt werden.",
                }
            )
            return json.dumps(payload, ensure_ascii=False)
        if requested_id != current_id:
            self._store_active_company_pdf(settings)
            settings["selected_company_id"] = requested_id
            self._load_active_company_pdf(settings)
            save_settings(settings)
            settings = load_settings()
            self._reset_workflow_state()
            self._restore_workflow_session(settings)
            self.processingStateChanged.emit(json.dumps(self._processing_payload(settings), ensure_ascii=False))
            self.shippingStateChanged.emit(json.dumps(self._shipping_payload(settings), ensure_ascii=False))
        payload = self._company_payload(settings)
        payload.update({"ok": True, "message": "Aktiver Mandant wurde gewechselt."})
        return json.dumps(payload, ensure_ascii=False)

    @Slot(str, result=str)
    def createCompany(self, payload: str) -> str:
        try:
            if self._workflow_running():
                raise ValueError("Ein Mandant kann während einer laufenden Prüfung oder eines Versands nicht erstellt werden.")
            data = json.loads(payload or "{}")
            if not isinstance(data, dict):
                raise ValueError("Ungültige Mandantendaten.")

            name = str(data.get("name", "") or "").strip()
            requested_id = str(data.get("id", "") or "").strip()
            choose_excel = bool(data.get("choose_excel"))
            if not name:
                raise ValueError("Bitte Unternehmensname eingeben.")

            settings = load_settings()
            companies = settings.setdefault("companies", [])
            if not isinstance(companies, list):
                companies = []
                settings["companies"] = companies

            existing_ids = {
                str(company.get("id", "") or "").strip().lower()
                for company in companies
                if isinstance(company, dict)
            }
            company_id = self._normalize_company_id(requested_id or name)
            if not company_id:
                company_id = "mandant"
            base_id = company_id
            suffix = 2
            while company_id.lower() in existing_ids:
                company_id = f"{base_id}-{suffix}"
                suffix += 1

            self._store_active_company_pdf(settings)
            companies.append({
                "id": company_id,
                "name": name,
                "email_excel_file": "",
                "pdf_input": "",
                "pdf_input_mode": "folder",
                "mail_settings": {"scope": "global"},
            })
            settings["selected_company_id"] = company_id
            self._load_active_company_pdf(settings)
            save_settings(settings)
            self._reset_workflow_state()

            if choose_excel:
                self.chooseExcelInput()

            settings = load_settings()
            self.processingStateChanged.emit(json.dumps(self._processing_payload(settings), ensure_ascii=False))
            self.shippingStateChanged.emit(json.dumps(self._shipping_payload(settings), ensure_ascii=False))
            return json.dumps(
                {
                    "ok": True,
                    "message": f"Mandant '{name}' wurde erstellt.",
                    "state": self._company_payload(settings),
                },
                ensure_ascii=False,
            )
        except Exception as exc:
            return json.dumps(
                {
                    "ok": False,
                    "message": f"Mandant konnte nicht erstellt werden: {exc}",
                    "state": self._company_payload(load_settings()),
                },
                ensure_ascii=False,
            )

    @Slot(str, result=str)
    def deleteCompany(self, company_id: str) -> str:
        try:
            if self._workflow_running():
                raise ValueError("Ein Mandant kann während einer laufenden Prüfung oder eines Versands nicht gelöscht werden.")

            requested_id = str(company_id or "").strip()
            settings = load_settings()
            companies = [
                company
                for company in settings.get("companies", [])
                if isinstance(company, dict)
            ]
            if len(companies) <= 1:
                raise ValueError("Der letzte Mandant kann nicht gelöscht werden.")

            delete_index = next(
                (
                    index
                    for index, company in enumerate(companies)
                    if str(company.get("id", "") or "").strip() == requested_id
                ),
                -1,
            )
            if delete_index < 0:
                raise ValueError("Der ausgewählte Mandant wurde nicht gefunden.")

            deleted_company = companies.pop(delete_index)
            settings["companies"] = companies
            if str(settings.get("selected_company_id", "") or "").strip() == requested_id:
                next_index = min(delete_index, len(companies) - 1)
                settings["selected_company_id"] = str(companies[next_index].get("id", "") or "").strip()

            save_settings(settings)
            delete_company_smtp_secret(requested_id)
            settings = load_settings()
            self._reset_workflow_state()
            self.processingStateChanged.emit(json.dumps(self._processing_payload(settings), ensure_ascii=False))
            self.shippingStateChanged.emit(json.dumps(self._shipping_payload(settings), ensure_ascii=False))
            self.massMessageStateChanged.emit(
                json.dumps(self._mass_message_payload(self._settings_with_company_mail(settings)), ensure_ascii=False)
            )
            payload = self._company_payload(settings)
            payload.update(
                {
                    "ok": True,
                    "message": f"Mandant '{deleted_company.get('name', requested_id)}' wurde gelöscht.",
                }
            )
            return json.dumps(payload, ensure_ascii=False)
        except Exception as exc:
            payload = self._company_payload(load_settings())
            payload.update({"ok": False, "message": f"Mandant konnte nicht gelöscht werden: {exc}"})
            return json.dumps(payload, ensure_ascii=False)

    @Slot(result=str)
    def chooseCompanyExcelInput(self) -> str:
        self.chooseExcelInput()
        return json.dumps(self._company_payload(load_settings()), ensure_ascii=False)

    @Slot(result=str)
    def openCompanyExcel(self) -> str:
        settings = load_settings()
        path = Path(str(get_company_email_excel_file(settings) or "")).expanduser()
        if not path.is_file():
            return json.dumps({"ok": False, "message": "Excel-Datei wurde noch nicht ausgewählt.", "path": ""}, ensure_ascii=False)
        opened = _open_target(path)
        return json.dumps(
            {
                "ok": bool(opened),
                "message": "Excel-Datei geöffnet." if opened else "Excel-Datei konnte nicht geöffnet werden.",
                "path": str(path),
            },
            ensure_ascii=False,
        )

    @Slot(result=str)
    def openOutputFolder(self) -> str:
        settings = load_settings()
        output_dir = company_output_dir(settings)
        output_dir.mkdir(parents=True, exist_ok=True)
        opened = _open_target(output_dir)
        return json.dumps(
            {
                "ok": bool(opened),
                "message": "Ausgabeordner geöffnet." if opened else "Ausgabeordner konnte nicht geöffnet werden.",
                "path": str(output_dir),
            },
            ensure_ascii=False,
        )

    @Slot(str, str, result=str)
    def exportValidationCsv(self, csv_text: str, filename: str) -> str:
        allowed, state = LicenseManager(load_settings()).require_action("export")
        if not allowed:
            return json.dumps({"ok": False, "message": state.get("last_message", "Lizenz erforderlich."), "path": ""}, ensure_ascii=False)

        safe_name = "".join(ch for ch in filename if ch.isalnum() or ch in {"-", "_", "."}).strip()
        if not safe_name.lower().endswith(".csv"):
            safe_name = f"{safe_name or 'lohnmail_pruefung'}.csv"

        settings = load_settings()
        export_dir = company_output_dir(settings) / "exports"
        export_dir.mkdir(parents=True, exist_ok=True)
        export_path = export_dir / safe_name
        export_path.write_text(csv_text, encoding="utf-8-sig")
        return json.dumps({"ok": True, "path": str(export_path)}, ensure_ascii=False)

    @Slot(str, str, result=str)
    def exportReportsCsv(self, csv_text: str, filename: str) -> str:
        allowed, state = LicenseManager(load_settings()).require_action("export")
        if not allowed:
            return json.dumps({"ok": False, "message": state.get("last_message", "Lizenz erforderlich."), "path": ""}, ensure_ascii=False)

        settings = load_settings()
        company_id = self._active_company_id(settings)
        if not company_id:
            return json.dumps({"ok": False, "message": "Bitte zuerst einen Mandanten auswählen.", "path": ""}, ensure_ascii=False)

        safe_name = "".join(ch for ch in filename if ch.isalnum() or ch in {"-", "_", "."}).strip()
        if not safe_name.lower().endswith(".csv"):
            safe_name = f"{safe_name or 'lohnmail_berichte'}.csv"
        export_dir = company_output_dir(settings, company_id) / "exports"
        export_dir.mkdir(parents=True, exist_ok=True)
        export_path = export_dir / safe_name
        export_path.write_text(csv_text, encoding="utf-8-sig")
        return json.dumps({"ok": True, "path": str(export_path)}, ensure_ascii=False)

    @Slot(str, result=str)
    def openReport(self, kind: str) -> str:
        filename = self.REPORT_FILES.get(str(kind or "").strip())
        if not filename:
            return json.dumps({"ok": False, "message": "Unbekannter Bericht.", "path": ""}, ensure_ascii=False)

        report = self._current_report_state(filename, load_settings())
        path = Path(str(report.get("path", "") or ""))
        if not report.get("exists") or not path.is_file():
            return json.dumps({"ok": False, "message": "Bericht wurde noch nicht erstellt.", "path": ""}, ensure_ascii=False)

        opened = _open_target(path)
        return json.dumps(
            {
                "ok": bool(opened),
                "message": "Bericht geöffnet." if opened else "Bericht konnte nicht geöffnet werden.",
                "path": str(path),
            },
            ensure_ascii=False,
        )

    @Slot(str, result=str)
    def openReportEntry(self, report_id: str) -> str:
        settings = load_settings()
        target = next(
            (
                item
                for item in self._reports_payload(settings).get("records", [])
                if str(item.get("id", "") or "") == str(report_id or "")
            ),
            None,
        )
        if not target:
            return json.dumps({"ok": False, "message": "Bericht gehört nicht zum aktiven Mandanten.", "path": ""}, ensure_ascii=False)

        path = Path(str(target.get("path", "") or "")).expanduser()
        if not target.get("exists") or not path.is_file() or not self._is_report_path_safe(path):
            return json.dumps({"ok": False, "message": "Berichtsdatei wurde nicht gefunden.", "path": str(path)}, ensure_ascii=False)
        opened = _open_target(path)
        return json.dumps(
            {
                "ok": bool(opened),
                "message": "Bericht geöffnet." if opened else "Bericht konnte nicht geöffnet werden.",
                "path": str(path),
            },
            ensure_ascii=False,
        )

    @Slot(result=str)
    def choosePdfInput(self) -> str:
        return json.dumps({"ok": False, "message": "Der native Dateidialog wird vom pywebview-Adapter bereitgestellt."}, ensure_ascii=False)

    @Slot(str, result=str)
    def setPdfInputMode(self, mode: str) -> str:
        settings = load_settings()
        if self._workflow_running():
            return self._emit_processing_payload(settings)
        resolved_mode = mode if mode in {"folder", "single_pdf"} else "folder"
        settings.setdefault("ui", {})["last_pdf_input_mode"] = resolved_mode
        self._set_company_pdf_input(settings, mode=resolved_mode)
        save_settings(settings)
        self._reset_workflow_state()
        payload = self._processing_payload(load_settings())
        serialized = json.dumps(payload, ensure_ascii=False)
        self.processingStateChanged.emit(serialized)
        self.shippingStateChanged.emit(json.dumps(self._shipping_payload(load_settings()), ensure_ascii=False))
        return serialized

    @Slot(result=str)
    def chooseExcelInput(self) -> str:
        return json.dumps({"ok": False, "message": "Der native Dateidialog wird vom pywebview-Adapter bereitgestellt."}, ensure_ascii=False)

    @Slot(result=str)
    def startCheck(self) -> str:
        if self._processing_running or self._shipping_running or self._mass_message_running:
            return self._emit_processing_payload(load_settings())

        settings = load_settings()
        allowed, license_state = LicenseManager(settings).require_action("processing")
        if not allowed:
            self._processing_status = {
                **self._idle_processing_status(),
                "can_check": False,
                "current_step": "Lizenz erforderlich",
                "errors": 1,
                "message": license_state.get("last_message", "Bitte aktivieren Sie eine gültige Lizenz."),
            }
            return self._emit_processing_payload(settings)

        company_id = self._active_company_id(settings)
        if not company_id:
            self._processing_status = {
                **self._idle_processing_status(),
                "can_check": False,
                "current_step": "Mandant auswählen",
                "warnings": 1,
                "message": "Bitte zuerst einen Mandanten auswählen.",
            }
            return self._emit_processing_payload(settings)

        ui_settings = settings.get("ui", {})
        pdf_input = Path(str(ui_settings.get("last_pdf_dir", "") or "")).expanduser()
        excel_path = Path(str(get_company_email_excel_file(settings, company_id) or "")).expanduser()
        pdf_expected = "pdf" if self._pdf_input_mode(settings) == "single_pdf" else "folder"
        pdf_state = self._path_state(str(pdf_input), expected=pdf_expected)
        excel_state = self._path_state(str(excel_path), expected="excel")

        if not pdf_state["valid"] or not excel_state["valid"]:
            self._processing_status = {
                **self._idle_processing_status(),
                "can_check": False,
                "current_step": "Eingaben prüfen",
                "warnings": 1,
                "message": "Bitte zuerst gültigen PDF-Eingang und eine Excel-Datei auswählen.",
            }
            return self._emit_processing_payload(settings)

        self._reset_validation_and_shipping()
        self._processing_company_id = company_id
        self._processing_input_signature = self._input_signature(settings)
        self._processing_running = True
        self._processing_status = {
            **self._idle_processing_status(),
            "running": True,
            "can_check": False,
            "current_step": "Prüfung läuft",
            "progress": 8,
            "message": "Prüfung läuft. Core-Verarbeitung wurde gestartet.",
        }
        self._emit_processing_payload(settings)
        self.shippingStateChanged.emit(json.dumps(self._shipping_payload(settings), ensure_ascii=False))

        def run_check() -> None:
            try:
                from core.jobs import run_main_job

                result = run_main_job(
                    mode="check",
                    pdf_input=pdf_input,
                    excel_path=excel_path,
                    settings=settings,
                    dry_run=bool(ui_settings.get("dry_run_default", True)),
                    progress_cb=self._on_processing_progress,
                )
                self._on_processing_finished(result)
            except Exception as exc:
                self._on_processing_error(ProcessingWorker._friendly_error(exc))

        threading.Thread(target=run_check, name="lohnmail-pywebview-check", daemon=True).start()

        return json.dumps(self._processing_payload(settings), ensure_ascii=False)

    @Slot(result=str)
    def startShippingDryRun(self) -> str:
        return self._start_shipping(dry_run=True)

    @Slot(result=str)
    def startShippingSend(self) -> str:
        return self._start_shipping(dry_run=False)

    @Slot(str, result=str)
    def startSelectedShippingSend(self, selected_json: str) -> str:
        return self._start_shipping(dry_run=False, selected_persnr=self._parse_selected_persnr(selected_json))

    @Slot(result=str)
    def previewShippingSend(self) -> str:
        return self._preview_shipping_send(selected_persnr=None)

    @Slot(str, result=str)
    def previewSelectedShippingSend(self, selected_json: str) -> str:
        return self._preview_shipping_send(selected_persnr=self._parse_selected_persnr(selected_json))

    def _preview_shipping_send(self, selected_persnr: set[str] | None) -> str:
        settings = self._settings_with_company_mail(load_settings())
        company_id = self._active_company_id(settings)
        rows = self._shipping_source_rows
        try:
            if self._shipping_running or self._processing_running or self._mass_message_running:
                raise ValueError("Bitte warten, bis der aktuelle Lauf abgeschlossen ist.")
            if (
                self._shipping_company_id != company_id
                or self._shipping_input_signature != self._shipping_signature(settings)
            ):
                raise ValueError("Die Versandvorbereitung gehört nicht zum aktiven Mandanten. Bitte Versand erneut vorbereiten.")
            if not self._shipping_status.get("finished") or self._shipping_status.get("dry_run") is not True or not rows:
                raise ValueError("Bitte zuerst Versand vorbereiten.")

            from core.message_templates import (
                append_pdf_password_notice,
                build_mail_context,
                build_send_preview_data,
                format_message_template,
            )

            preview = build_send_preview_data(
                settings=settings,
                table_rows=rows,
                dry_run=False,
                summary={
                    "missing_email_count": sum(1 for row in rows if row.get("Status") == "Keine E-Mail"),
                    "missing_files_count": sum(1 for row in rows if row.get("Status") == "Keine Dateien"),
                },
                selected_persnr=selected_persnr,
            )
            preview_rows = preview.get("preview_rows", [])
            if not preview_rows:
                raise ValueError("Es gibt keine sendbaren Einträge mit E-Mail und PDF-Anhang.")

            sample_persnr = str(preview_rows[0].get("PersNr", "") or "")
            context = build_mail_context(
                settings,
                sample_persnr,
                company_id=str(settings.get("selected_company_id", "") or "").strip() or None,
            )
            mail_text = settings.get("mail_text", {})
            body_template = str(mail_text.get("body", "") or "")
            body_html_template = str(mail_text.get("body_html", "") or "")
            body_preview = format_message_template(body_template, context) if body_template else ""
            body_html_preview = (
                format_message_template(body_html_template, context)
                if body_html_template
                else ""
            )
            if not body_preview and body_html_preview:
                body_preview = re.sub(r"<[^>]+>", " ", body_html_preview)
                body_preview = " ".join(body_preview.split())
            body_preview, body_html_preview = append_pdf_password_notice(
                body_preview,
                body_html_preview,
                settings.get("pdf_password", {}),
            )
            smtp_settings = settings.get("smtp", {})
            return json.dumps(
                {
                    "ok": True,
                    "message": "Versand-Vorschau ist bereit.",
                    "mail_mode": str(settings.get("mail_mode", "smtp") or "smtp"),
                    "from_email": str(smtp_settings.get("from_email", "") or ""),
                    "from_name": str(smtp_settings.get("from_name", "") or ""),
                    "summary_lines": preview.get("summary_lines", []),
                    "subject_preview": preview.get("subject_preview", ""),
                    "body_preview": body_preview,
                    "body_html_preview": body_html_preview,
                    "rows": preview_rows,
                    "total_count": len(preview_rows),
                },
                ensure_ascii=False,
            )
        except Exception as exc:
            return json.dumps({"ok": False, "message": str(exc)}, ensure_ascii=False)

    def _start_shipping(self, dry_run: bool, selected_persnr: set[str] | None = None) -> str:
        if self._shipping_running or self._processing_running or self._mass_message_running:
            return self._emit_shipping_payload(self._settings_with_company_mail(load_settings()))

        settings = self._settings_with_company_mail(load_settings())
        company_id = self._active_company_id(settings)
        allowed, license_state = LicenseManager(settings).require_action("shipping")
        if not allowed:
            self._shipping_status = {
                **self._idle_shipping_status(),
                "can_send": False,
                "current_step": "Lizenz erforderlich",
                "errors": 1,
                "message": license_state.get("last_message", "Bitte aktivieren Sie eine gültige Lizenz."),
            }
            return self._emit_shipping_payload(settings)

        if not company_id:
            self._shipping_status = {
                **self._idle_shipping_status(),
                "can_send": False,
                "current_step": "Mandant auswählen",
                "errors": 1,
                "message": "Bitte zuerst einen Mandanten auswählen.",
            }
            return self._emit_shipping_payload(settings)

        if self._validation_company_id != company_id or not self._validation_state.get("ready"):
            self._shipping_status = {
                **self._idle_shipping_status(),
                "can_send": False,
                "current_step": "Prüfung erforderlich",
                "errors": 1,
                "message": "Bitte zuerst die Prüfung für den aktiven Mandanten abschließen.",
            }
            return self._emit_shipping_payload(settings)

        current_input_signature = self._input_signature(settings)
        current_shipping_signature = self._shipping_signature(settings)
        if self._validation_input_signature != current_input_signature:
            self._shipping_status = {
                **self._idle_shipping_status(),
                "can_send": False,
                "current_step": "Erneute Prüfung erforderlich",
                "errors": 1,
                "message": "PDF- oder Excel-Eingabe wurde seit der Prüfung geändert. Bitte den aktiven Mandanten erneut prüfen.",
            }
            return self._emit_shipping_payload(settings)

        if not dry_run and (
            self._shipping_company_id != company_id
            or self._shipping_input_signature != current_shipping_signature
            or not self._shipping_status.get("finished")
            or self._shipping_status.get("dry_run") is not True
            or not self._shipping_source_rows
        ):
            self._shipping_status = {
                **self._idle_shipping_status(),
                "can_send": False,
                "current_step": "Vorbereitung erforderlich",
                "errors": 1,
                "message": "Bitte Versand für den aktiven Mandanten erneut vorbereiten.",
            }
            return self._emit_shipping_payload(settings)

        ui_settings = settings.get("ui", {})
        pdf_input = Path(str(ui_settings.get("last_pdf_dir", "") or "")).expanduser()
        excel_path = Path(str(get_company_email_excel_file(settings, company_id) or "")).expanduser()
        pdf_expected = "pdf" if self._pdf_input_mode(settings) == "single_pdf" else "folder"
        pdf_state = self._path_state(str(pdf_input), expected=pdf_expected)
        excel_state = self._path_state(str(excel_path), expected="excel")

        if not pdf_state["valid"] or not excel_state["valid"]:
            self._shipping_status = {
                **self._idle_shipping_status(),
                "can_send": False,
                "current_step": "Eingaben prüfen",
                "errors": 1,
                "message": "Bitte zuerst gültigen PDF-Eingang und eine Excel-Datei auswählen.",
            }
            return self._emit_shipping_payload(settings)

        if dry_run:
            self._shipping_rows = []
            self._shipping_source_rows = []
        self._shipping_company_id = company_id
        self._shipping_input_signature = current_shipping_signature
        self._shipping_running = True
        self._shipping_status = {
            **self._idle_shipping_status(),
            "running": True,
            "can_send": False,
            "current_step": "Versand wird vorbereitet" if dry_run else "E-Mails werden gesendet",
            "progress": 8,
            "dry_run": dry_run,
            "message": "Dry-Run läuft. Anhänge und Versandbericht werden vorbereitet." if dry_run else "E-Mail Versand läuft. Verbindung und Anhänge werden geprüft.",
        }
        self._emit_shipping_payload(settings)

        def run_shipping() -> None:
            try:
                from core.jobs import run_main_job

                result = run_main_job(
                    mode="send",
                    pdf_input=pdf_input,
                    excel_path=excel_path,
                    settings=settings,
                    dry_run=dry_run,
                    selected_persnr=selected_persnr,
                    progress_cb=self._on_shipping_progress,
                )
                self._on_shipping_finished(result)
            except Exception as exc:
                self._on_shipping_error(ProcessingWorker._friendly_error(exc))

        self.worker_thread = threading.Thread(
            target=run_shipping,
            name="lohnmail-pywebview-shipping",
            daemon=True,
        )
        self.worker_thread.start()

        return json.dumps(self._shipping_payload(settings), ensure_ascii=False)

    def _processing_payload(self, settings: dict) -> dict:
        ui_settings = settings.get("ui", {})
        company_id = self._active_company_id(settings)
        pdf_input_mode = self._pdf_input_mode(settings)

        pdf_input = str(ui_settings.get("last_pdf_dir", "") or "").strip()
        excel_file = str(get_company_email_excel_file(settings, company_id) or "").strip()

        pdf_state = self._path_state(
            pdf_input,
            expected="pdf" if pdf_input_mode == "single_pdf" else "folder",
        )
        excel_state = self._path_state(excel_file, expected="excel")
        output_dir = company_output_dir(settings)
        output_dir.mkdir(parents=True, exist_ok=True)
        output_state = self._path_state(str(output_dir), expected="folder")
        can_check = bool(pdf_state["valid"] and excel_state["valid"] and output_state["valid"])
        status = {**self._processing_status}
        if not status.get("running"):
            status["can_check"] = can_check
            if not status.get("finished") and not status.get("failed"):
                status["current_step"] = "Bereit" if can_check else "Eingaben prüfen"
                status["warnings"] = 0 if can_check else 1
                status["message"] = (
                    "Eingaben bereit. Prüfung kann gestartet werden."
                    if can_check
                    else "Bitte gültigen PDF-Eingang und eine Excel-Datei auswählen."
                )

        return {
            "company": {
                "id": company_id,
                "name": get_company_name(settings),
            },
            "mode": pdf_input_mode,
            "dry_run_default": bool(ui_settings.get("dry_run_default", True)),
            "inputs": {
                "pdf": pdf_state,
                "excel": excel_state,
                "output": output_state,
            },
            "status": status,
        }

    def _emit_processing_payload(self, settings: dict) -> str:
        self._persist_workflow_session(settings)
        serialized = json.dumps(self._processing_payload(settings), ensure_ascii=False)
        self.processingStateChanged.emit(serialized)
        return serialized

    def _shipping_payload(self, settings: dict) -> dict:
        company_id = self._active_company_id(settings)
        current_input_signature = self._input_signature(settings)
        current_shipping_signature = self._shipping_signature(settings)
        shipping_matches = bool(
            company_id
            and self._shipping_company_id == company_id
            and self._shipping_input_signature == current_shipping_signature
        )
        validation_matches = bool(
            company_id
            and self._validation_company_id == company_id
            and self._validation_input_signature == current_input_signature
        )
        rows = self._shipping_rows if shipping_matches else []
        if not rows and validation_matches:
            rows = self._shipping_rows_from_validation()
        status = {**(self._shipping_status if shipping_matches else self._idle_shipping_status())}
        inputs_ready = self._inputs_ready(settings)
        validation_ready = bool(validation_matches and self._validation_state.get("ready"))
        ready_count = sum(1 for row in rows if row.get("status") in {"Bereit", "Dry-Run", "Gesendet"})
        sent_count = sum(1 for row in rows if row.get("status") == "Gesendet")
        dry_run_count = sum(1 for row in rows if row.get("status") == "Dry-Run")
        skipped_count = sum(
            1
            for row in rows
            if row.get("status") in {
                "Keine E-Mail", "Keine Dateien", "Doppelte E-Mail", "Ungültige E-Mail",
                "Ungültige Zeichen", "Ungültiges Format", "Domain nicht gefunden", "Keine MX-Einträge",
            }
        )
        error_count = sum(1 for row in rows if row.get("status") == "Fehler")

        # Never expose a stale running flag after the worker has stopped.
        if status.get("running") and not self._shipping_running:
            status["running"] = False
            if sent_count > 0 and ready_count == sent_count:
                status["finished"] = True
                status["dry_run"] = False
                status["current_step"] = "Versand abgeschlossen"
                status["progress"] = 100
                status["message"] = f"Versand abgeschlossen. {sent_count} E-Mails wurden gesendet."

        if not status.get("running"):
            status["can_send"] = bool(inputs_ready and validation_ready)
            if not status.get("finished") and not status.get("failed"):
                status["current_step"] = "Bereit" if inputs_ready and validation_ready else "Prüfung erforderlich"
                status["message"] = (
                    "Versand kann als Dry-Run vorbereitet werden."
                    if inputs_ready and validation_ready
                    else "Bitte zuerst die Prüfung für den aktiven Mandanten abschließen."
                )

        return {
            "company": {
                "id": company_id,
                "name": get_company_name(settings, company_id),
            },
            "status": status,
            "metrics": {
                "ready": ready_count,
                "sent": sent_count,
                "queued": max(0, ready_count - sent_count),
                "errors": error_count,
                "exported": dry_run_count,
                "skipped": skipped_count,
                "total": len(rows),
            },
            "rows": rows,
            "reports": {"send": self._current_report_state("send_report.xlsx", settings)},
        }

    @staticmethod
    def _parse_selected_persnr(selected_json: str) -> set[str] | None:
        try:
            raw_values = json.loads(str(selected_json or "[]"))
        except Exception:
            raw_values = []
        if not isinstance(raw_values, list):
            return None
        selected = {
            str(value or "").strip()
            for value in raw_values
            if str(value or "").strip()
        }
        return selected if selected else set()

    @staticmethod
    def _selected_company(settings: dict) -> dict | None:
        selected_company_id = str(settings.get("selected_company_id", "") or "").strip()
        for company in settings.get("companies", []):
            if not isinstance(company, dict):
                continue
            if str(company.get("id", "") or "").strip() == selected_company_id:
                return company
        return None

    @staticmethod
    def _active_company_id(settings: dict) -> str:
        selected_company_id = str(settings.get("selected_company_id", "") or "").strip()
        for company in settings.get("companies", []):
            if not isinstance(company, dict):
                continue
            if str(company.get("id", "") or "").strip() == selected_company_id:
                return selected_company_id
        return ""

    def _workflow_running(self) -> bool:
        return bool(self._processing_running or self._shipping_running or self._mass_message_running)

    def _reset_validation_and_shipping(self) -> None:
        self._validation_company_id = ""
        self._validation_input_signature = None
        self._validation_state = self._empty_validation_state()
        self._shipping_company_id = ""
        self._shipping_input_signature = None
        self._shipping_running = False
        self._shipping_status = self._idle_shipping_status()
        self._shipping_rows = []
        self._shipping_source_rows = []

    def _reset_workflow_state(self) -> None:
        self._processing_company_id = ""
        self._processing_input_signature = None
        self._processing_running = False
        self._processing_status = self._idle_processing_status()
        self._reset_validation_and_shipping()
        self._mass_message_status = self._idle_mass_message_status()
        self._mass_message_preview = self._empty_mass_message_preview()

    def _persist_workflow_session(self, settings: dict | None = None) -> None:
        if not hasattr(self, "_workflow_sessions"):
            return
        resolved_settings = settings or load_settings()
        company_id = self._active_company_id(resolved_settings)
        if not company_id:
            return
        state = {
            "processing_company_id": self._processing_company_id,
            "processing_input_signature": list(self._processing_input_signature or ()),
            "processing_status": deepcopy(self._processing_status),
            "validation_company_id": self._validation_company_id,
            "validation_input_signature": list(self._validation_input_signature or ()),
            "validation_state": deepcopy(self._validation_state),
            "shipping_company_id": self._shipping_company_id,
            "shipping_input_signature": list(self._shipping_input_signature or ()),
            "shipping_status": deepcopy(self._shipping_status),
            "shipping_rows": deepcopy(self._shipping_rows),
            "shipping_source_rows": deepcopy(self._shipping_source_rows),
            "mass_message_status": deepcopy(self._mass_message_status),
            "mass_message_preview": deepcopy(self._mass_message_preview),
        }
        self._workflow_sessions.save(company_id, state)

    def _restore_workflow_session(self, settings: dict) -> None:
        company_id = self._active_company_id(settings)
        state = self._workflow_sessions.load(company_id) if company_id else {}
        if not state:
            return

        def signature(key: str) -> tuple[str, ...] | None:
            value = state.get(key)
            expected_length = 5 if key == "shipping_input_signature" else 4
            if isinstance(value, list) and len(value) == expected_length:
                return tuple(str(item or "") for item in value)
            return None

        self._processing_company_id = str(state.get("processing_company_id") or "")
        self._processing_input_signature = signature("processing_input_signature")
        self._processing_status = {**self._idle_processing_status(), **dict(state.get("processing_status") or {})}
        self._validation_company_id = str(state.get("validation_company_id") or "")
        self._validation_input_signature = signature("validation_input_signature")
        self._validation_state = {**self._empty_validation_state(), **dict(state.get("validation_state") or {})}
        self._shipping_company_id = str(state.get("shipping_company_id") or "")
        self._shipping_input_signature = signature("shipping_input_signature")
        self._shipping_status = {**self._idle_shipping_status(), **dict(state.get("shipping_status") or {})}
        self._shipping_rows = list(state.get("shipping_rows") or [])
        self._shipping_source_rows = list(state.get("shipping_source_rows") or [])
        self._mass_message_status = {**self._idle_mass_message_status(), **dict(state.get("mass_message_status") or {})}
        self._mass_message_preview = {**self._empty_mass_message_preview(), **dict(state.get("mass_message_preview") or {})}

        current_signature = self._input_signature(settings)
        if self._processing_input_signature and self._processing_input_signature != current_signature:
            self._reset_workflow_state()
            return
        if self._processing_status.get("running"):
            self._processing_status.update(
                running=False,
                finished=False,
                failed=False,
                can_check=True,
                current_step="Unterbrochene Prüfung",
                message="Die vorherige Prüfung wurde unterbrochen. Sie kann mit den gespeicherten Eingaben erneut gestartet werden.",
            )
        if self._shipping_status.get("running"):
            self._shipping_status.update(
                running=False,
                finished=False,
                failed=False,
                can_send=bool(self._validation_state.get("ready")),
                current_step="Unterbrochener Versand",
                message="Der vorherige Versand wurde unterbrochen. Bitte Vorschau prüfen und erneut starten.",
            )
        if self._mass_message_status.get("running"):
            self._mass_message_status.update(
                running=False,
                finished=False,
                failed=False,
                current_step="Unterbrochene Nachricht",
                message="Der vorherige Nachrichtenversand wurde unterbrochen und kann erneut gestartet werden.",
            )
        self._processing_running = False
        self._shipping_running = False
        self._mass_message_running = False

    def _input_signature(self, settings: dict) -> tuple[str, str, str, str]:
        company_id = self._active_company_id(settings)
        ui_settings = settings.get("ui", {})
        raw_pdf_input = str(ui_settings.get("last_pdf_dir", "") or "").strip()
        raw_excel_input = str(get_company_email_excel_file(settings, company_id) or "").strip()
        pdf_input = Path(raw_pdf_input).expanduser() if raw_pdf_input else None
        excel_input = Path(raw_excel_input).expanduser() if raw_excel_input else None
        return (
            company_id,
            self._pdf_input_mode(settings),
            str(pdf_input.resolve(strict=False)) if pdf_input else "",
            str(excel_input.resolve(strict=False)) if excel_input else "",
        )

    def _shipping_signature(self, settings: dict) -> tuple[str, ...]:
        effective = self._settings_with_company_mail(settings)
        smtp = effective.get("smtp", {}) if isinstance(effective.get("smtp"), dict) else {}
        identity = {
            "mail_mode": str(effective.get("mail_mode", "smtp") or "smtp").strip().lower(),
            "server": str(smtp.get("server", "") or "").strip(),
            "port": int(smtp.get("port", 0) or 0),
            "security": str(smtp.get("security", "") or "").strip().lower(),
            "username": str(smtp.get("username", "") or "").strip(),
            "from_email": str(smtp.get("from_email", "") or "").strip().lower(),
            "from_name": str(smtp.get("from_name", "") or "").strip(),
        }
        digest = hashlib.sha256(
            json.dumps(identity, ensure_ascii=False, sort_keys=True).encode("utf-8")
        ).hexdigest()
        return (*self._input_signature(effective), digest)

    @staticmethod
    def _company_mail_settings(company: dict | None) -> dict:
        if not isinstance(company, dict):
            return {"scope": "global", "smtp": {}}
        mail_settings = company.get("mail_settings")
        if not isinstance(mail_settings, dict):
            return {"scope": "global", "smtp": {}}
        scope = str(mail_settings.get("scope", "global") or "global").strip().lower()
        if scope not in {"global", "custom"}:
            scope = "global"
        smtp = mail_settings.get("smtp") if isinstance(mail_settings.get("smtp"), dict) else {}
        return {"scope": scope, "smtp": smtp}

    def _settings_with_company_mail(self, settings: dict) -> dict:
        effective = deepcopy(settings)
        company = self._selected_company(effective)
        mail_settings = self._company_mail_settings(company)
        if mail_settings.get("scope") != "custom":
            return effective

        effective["mail_mode"] = "smtp"
        effective_smtp = effective.setdefault("smtp", {})
        for key, value in mail_settings.get("smtp", {}).items():
            if key == "password":
                if str(value or ""):
                    effective_smtp[key] = str(value)
                continue
            effective_smtp[key] = value
        return effective

    def _company_payload(self, settings: dict) -> dict:
        selected_company_id = str(settings.get("selected_company_id", "") or "").strip()
        companies = []
        for company in settings.get("companies", []):
            if not isinstance(company, dict):
                continue
            company_id = str(company.get("id", "") or "").strip()
            excel_file = str(company.get("email_excel_file", "") or "").strip()
            mail_settings = self._company_mail_settings(company)
            companies.append(
                {
                    "id": company_id,
                    "name": str(company.get("name", "") or company_id),
                    "selected": company_id == selected_company_id,
                    "excel": self._path_state(excel_file, expected="excel"),
                    "mail_scope": mail_settings.get("scope", "global"),
                }
            )

        selected_company = self._selected_company(settings)
        company_mail = self._company_mail_settings(selected_company)
        effective_settings = self._settings_with_company_mail(settings)
        smtp_settings = effective_settings.get("smtp", {})
        license_settings = settings.get("license", {})
        period_settings = settings.get("period", {})
        selected_excel = str(get_company_email_excel_file(settings) or "").strip()
        smtp_server = str(smtp_settings.get("server", "") or "").strip()
        smtp_from = str(smtp_settings.get("from_email", "") or smtp_settings.get("username", "") or "").strip()
        license_status = str(license_settings.get("status", "") or "unregistered").strip().lower()

        return {
            "selected_company_id": selected_company_id,
            "selected_company_name": get_company_name(settings),
            "companies": companies,
            "selected_excel": self._path_state(selected_excel, expected="excel"),
            "output": self._path_state(str(company_output_dir(settings)), expected="folder"),
            "smtp": {
                "server": smtp_server,
                "from": smtp_from,
                "configured": bool(smtp_server and smtp_from),
                "label": ("Eigene SMTP" if company_mail.get("scope") == "custom" else "Global SMTP") if smtp_server and smtp_from else "Nicht konfiguriert",
                "mode": str(effective_settings.get("mail_mode", "smtp") or "smtp"),
                "scope": company_mail.get("scope", "global"),
                "password_set": bool(str(company_mail.get("smtp", {}).get("password", "") or "")),
                "settings": {
                    "server": str(company_mail.get("smtp", {}).get("server", "") or ""),
                    "port": int(company_mail.get("smtp", {}).get("port", 587) or 587),
                    "security": str(company_mail.get("smtp", {}).get("security", "tls") or "tls"),
                    "username": str(company_mail.get("smtp", {}).get("username", "") or ""),
                    "from_email": str(company_mail.get("smtp", {}).get("from_email", "") or ""),
                    "from_name": str(company_mail.get("smtp", {}).get("from_name", "") or ""),
                    "timeout_sec": int(company_mail.get("smtp", {}).get("timeout_sec", 30) or 30),
                },
            },
            "license": {
                "status": license_status,
                "label": "Aktiv" if license_status in {"active", "business", "registered", "valid"} else "Nicht registriert",
            },
            "period": {
                "mode": str(period_settings.get("mode", "") or "automatic_current_month"),
                "month": int(period_settings.get("month", 0) or 0),
                "year": int(period_settings.get("year", 0) or 0),
            },
        }

    def _license_payload(self, settings: dict, refresh: bool = False, state: dict | None = None) -> dict:
        manager = LicenseManager(settings)
        state = state or (manager.refresh(force=False, start_trial=True) if refresh else manager.load_state())
        licensee = self._licensee_settings(settings, state)
        raw_key = str(state.get("license_key", "") or settings.get("license", {}).get("key", "") or "").strip()
        related_trial_key = str(state.get("related_trial_license_key", "") or "").strip()
        status = str(state.get("status", "") or "unregistered").strip().lower()
        license_type = str(state.get("type", "") or "none").strip().lower()
        active = status in {"trialing", "active", "expiring_soon", "license_problem"}
        status_label = self._license_label(status, license_type, state)
        status_level = self._license_status_level(status, active, manager.server_url)
        trial_ends_at = str(state.get("trial_ends_at", "") or "")
        related_trial_ends_at = str(state.get("related_trial_ends_at", "") or "")
        current_period_end = str(state.get("current_period_end", "") or "")
        access_ends_at = str(
            state.get("access_ends_at", "")
            or current_period_end
            or trial_ends_at
            or related_trial_ends_at
            or ""
        )
        license_problem = status == "license_problem"
        grace_ends_at = str(state.get("license_problem_grace_ends_at", "") or "")
        return {
            "status": status,
            "label": status_label,
            "status_level": status_level,
            "active": active,
            "key_masked": str(state.get("license_key_masked", "") or self._mask_license_key(raw_key)),
            "key_label": "Bisheriger Lizenzschlüssel (nicht gefunden)" if license_problem else "Lizenzschlüssel",
            "key_present": bool(raw_key),
            "type": "Übergangsfrist" if license_problem else self._license_type_label(license_type),
            "plan": "-" if license_problem else str(state.get("plan", "") or ("Trial" if license_type == "trial" else "Professional")),
            "seats": str(state.get("seats", "") or "1"),
            "server": str(state.get("server", "") or ("Verbunden" if manager.server_url else "Nicht konfiguriert")),
            "server_note": "Online-Prüfung aktiv" if manager.server_url else "Keine Serverlogik aktiv",
            "mode": "Server" if manager.server_url else "Lokal",
            "company": licensee.get("name") or str(state.get("company_name", "") or "") or "-",
            "licensee": licensee,
            "machine_id": str(state.get("machine_id", "") or ""),
            "licensed_machine_id": str(state.get("licensed_machine_id", "") or ""),
            "days_remaining": state.get("days_remaining"),
            "trial_ends_at": "" if license_problem else trial_ends_at,
            "current_period_end": "" if license_problem else current_period_end,
            "access_ends_at": grace_ends_at if license_problem else access_ends_at,
            "related_trial_ends_at": "" if license_problem else related_trial_ends_at,
            "related_trial_key_masked": "" if license_problem else (self._mask_license_key(related_trial_key) if related_trial_key else ""),
            "license_problem_grace_ends_at": grace_ends_at,
            "message": self._license_message(status, state),
            "state_list": self._license_state_list(status),
            "features": [
                {"name": "PDF Import", "enabled": True},
                {"name": "Excel Import", "enabled": True},
                {"name": "Prüfung", "enabled": True},
                {"name": "Versand", "enabled": active or not manager.server_url},
                {"name": "Lizenzserver", "enabled": bool(manager.server_url)},
            ],
            "history": [
                {
                    "date": str(state.get("last_successful_check_at", "") or "Noch nicht geprüft"),
                    "action": "Lizenzprüfung",
                    "computer": str(state.get("machine_id", "") or "-"),
                    "user": "-",
                    "status": status_label,
                }
            ],
        }

    @staticmethod
    def _licensee_settings(settings: dict, state: dict | None = None) -> dict:
        state = state or {}
        configured = settings.get("licensee") if isinstance(settings.get("licensee"), dict) else {}
        name = str(
            configured.get("name", "")
            or state.get("licensee_name", "")
            or state.get("company_name", "")
            or ""
        ).strip()
        email = str(
            configured.get("email", "")
            or state.get("licensee_email", "")
            or state.get("email", "")
            or ""
        ).strip()
        return {
            "name": name,
            "email": email,
            "address": str(configured.get("address", "") or state.get("licensee_address", "") or "").strip(),
            "company_number": str(
                configured.get("company_number", "")
                or state.get("licensee_company_number", "")
                or ""
            ).strip(),
        }

    @staticmethod
    def _mask_license_key(value: str) -> str:
        if not value:
            return "Nicht hinterlegt"
        return f"{value[:8]}-••••-{value[-4:]}"

    @staticmethod
    def _license_type_label(value: str) -> str:
        labels = {
            "trial": "Trial",
            "subscription": "Subscription",
            "lifetime": "Lifetime",
            "demo": "Demo",
            "internal": "Internal",
            "none": "Nicht registriert",
        }
        return labels.get(value, value or "Nicht registriert")

    @staticmethod
    def _license_label(status: str, license_type: str, state: dict) -> str:
        days = state.get("days_remaining")
        if status == "trialing" and license_type == "subscription":
            suffix = f" · {days} Tage verbleibend" if days is not None else ""
            return f"Professional · Probezeit{suffix}"
        if status == "trialing":
            suffix = f" · {days} Tage verbleibend" if days is not None else ""
            return f"Trial{suffix}"
        if license_type == "lifetime" and status == "active":
            return "Lifetime"
        if status == "active":
            return "Active · Professional"
        if status == "expiring_soon":
            return "Läuft bald ab"
        if status == "past_due":
            return "Zahlung überfällig"
        if status == "unpaid":
            return "Zahlung offen"
        if status == "canceled":
            return "Gekündigt"
        if status == "refunded":
            return "Erstattet"
        if status == "disputed":
            return "Zahlung angefochten"
        if status == "revoked":
            return "Widerrufen"
        if status == "invalid":
            return "Ungültig"
        if status == "device_mismatch":
            return "Anderer Computer"
        if status == "license_problem":
            suffix = f" · {days} Tage Übergangsfrist" if days is not None else ""
            return f"Lizenzproblem{suffix}"
        if status == "expired":
            return "Abgelaufen"
        if status == "no_connection":
            return "Keine Verbindung"
        return "Nicht registriert"

    @staticmethod
    def _license_status_level(status: str, active: bool, server_url: str) -> str:
        if status in {"past_due", "expired", "unpaid", "canceled", "refunded", "disputed", "revoked", "invalid", "device_mismatch"}:
            return "error"
        if status in {"expiring_soon", "no_connection", "license_problem"}:
            return "warning"
        if active:
            return "ready"
        return "warning" if server_url else "neutral"

    @staticmethod
    def _license_message(status: str, state: dict) -> str:
        if status == "invalid" and state.get("license_problem_started_at"):
            return str(state.get("last_message", "") or "Die Übergangsfrist ist abgelaufen. Bitte aktivieren Sie eine neue Lizenz.")
        messages = {
            "trialing": "Testphase aktiv. LohnMail kann während der Testphase genutzt werden.",
            "active": "Lizenz aktiv. Alle freigeschalteten Aktionen sind verfügbar.",
            "expiring_soon": "Lizenz läuft bald ab. Bitte prüfen Sie die Verlängerung.",
            "past_due": "Zahlung überfällig. Bitte offene Rechnung begleichen oder Zahlungsdaten im Kundenportal aktualisieren.",
            "unpaid": "Lizenz wegen offener Zahlung gesperrt.",
            "canceled": "Lizenz gekündigt. Nutzung ist nach Ablauf der Periode gesperrt.",
            "expired": "Lizenz oder Testphase abgelaufen.",
            "refunded": "Zahlung erstattet. Lizenz gesperrt.",
            "disputed": "Zahlung angefochten. Lizenz gesperrt.",
            "revoked": "Lizenz wurde widerrufen.",
            "invalid": "Lizenz ist ungültig oder an einen anderen Computer gebunden.",
            "device_mismatch": "Diese Lizenz ist an einen anderen Computer gebunden. Bitte wenden Sie sich an den LohnMail-Support.",
            "license_problem": str(state.get("last_message", "") or "Lizenz nicht gefunden. Bitte aktivieren Sie innerhalb von 14 Tagen eine neue Lizenz."),
            "no_connection": "Lizenzserver nicht erreichbar. Offline-Gnadenfrist wird geprüft.",
            "unregistered": "Keine Lizenz hinterlegt.",
        }
        return messages.get(status) or str(state.get("last_message", "") or "Lizenzstatus geladen.")

    @classmethod
    def _license_state_list(cls, current_status: str) -> list[dict]:
        groups = [
            ("trialing", "Trial", "info"),
            ("active", "Aktiv", "success"),
            ("expiring_soon", "Läuft bald ab", "warning"),
            ("past_due", "Zahlung überfällig", "warning"),
            ("unpaid", "Unbezahlt", "error"),
            ("canceled", "Gekündigt", "error"),
            ("expired", "Abgelaufen", "error"),
            ("refunded", "Erstattet", "error"),
            ("disputed", "Angefochten", "error"),
            ("revoked", "Widerrufen", "error"),
            ("invalid", "Ungültig", "error"),
            ("device_mismatch", "Anderer Computer", "error"),
            ("license_problem", "Lizenzproblem", "warning"),
            ("no_connection", "Keine Verbindung", "warning"),
        ]
        return [
            {
                "status": status,
                "label": label,
                "level": level,
                "active": status == current_status,
            }
            for status, label, level in groups
        ]

    def _settings_payload(self, settings: dict) -> dict:
        smtp = settings.get("smtp", {})
        mail_text = settings.get("mail_text", {})
        pdf_password = settings.get("pdf_password", {})
        period = settings.get("period", {})
        ui_settings = settings.get("ui", {})
        notification_settings = settings.get("notifications", {})
        return {
            "mail_mode": str(settings.get("mail_mode", "smtp") or "smtp"),
            "smtp": {
                "server": str(smtp.get("server", "") or ""),
                "port": int(smtp.get("port", 587) or 587),
                "security": str(smtp.get("security", "tls") or "tls"),
                "username": str(smtp.get("username", "") or ""),
                "password_set": bool(str(smtp.get("password", "") or "")),
                "timeout_sec": int(smtp.get("timeout_sec", 30) or 30),
                "from_email": str(smtp.get("from_email", "") or ""),
                "from_name": str(smtp.get("from_name", "Personalabteilung") or "Personalabteilung"),
            },
            "mail_text": {
                "subject": str(mail_text.get("subject", "") or ""),
                "body": str(mail_text.get("body", "") or ""),
                "body_html": str(mail_text.get("body_html", "") or ""),
            },
            "pdf_password": {
                "enabled": bool(pdf_password.get("enabled", True)),
                "source": (
                    str(pdf_password.get("source", "persnr") or "persnr")
                    if str(pdf_password.get("source", "persnr") or "persnr") in {"persnr", "birth_date"}
                    else "persnr"
                ),
                "prefix": str(pdf_password.get("prefix", "") or ""),
                "suffix": str(pdf_password.get("suffix", "") or ""),
            },
            "period": {
                "mode": str(period.get("mode", "automatic_current_month") or "automatic_current_month"),
                "month": int(period.get("month", datetime.now().month) or datetime.now().month),
                "year": int(period.get("year", datetime.now().year) or datetime.now().year),
            },
            "ui": {
                "dry_run_default": bool(ui_settings.get("dry_run_default", True)),
                "remember_last_paths": bool(ui_settings.get("remember_last_paths", True)),
            },
            "notifications": {
                "show_badge": bool(notification_settings.get("show_badge", True)),
                "workflow_warnings": bool(notification_settings.get("workflow_warnings", True)),
                "validation_warnings": bool(notification_settings.get("validation_warnings", True)),
                "processing_errors": bool(notification_settings.get("processing_errors", True)),
                "delivery_events": bool(notification_settings.get("delivery_events", True)),
                "auto_open_on_start": bool(notification_settings.get("auto_open_on_start", False)),
            },
            "company": self._company_payload(settings),
            "licensee": self._licensee_settings(settings),
            "license": self._license_payload(settings),
            "outlook_supported": True,
        }

    def _mass_message_payload(self, settings: dict) -> dict:
        company_id = str(settings.get("selected_company_id", "") or "").strip()
        excel_file = str(get_company_email_excel_file(settings, company_id) or "").strip()
        preview_payload = {
            key: value
            for key, value in self._mass_message_preview.items()
            if key != "recipients"
        }
        return {
            "status": {**self._mass_message_status},
            "preview": preview_payload,
            "company": {
                "id": company_id,
                "name": get_company_name(settings, company_id),
            },
            "excel": self._path_state(excel_file, expected="excel"),
            "mail_mode": str(settings.get("mail_mode", "smtp") or "smtp"),
        }

    def _emit_mass_message_payload(self, settings: dict) -> str:
        self._persist_workflow_session(settings)
        serialized = json.dumps(self._mass_message_payload(settings), ensure_ascii=False)
        self.massMessageStateChanged.emit(serialized)
        return serialized

    def _build_mass_message_preview(self, settings: dict, subject: str, body: str) -> dict:
        from core.jobs import load_mass_message_rows
        from core.message_templates import build_mail_context, format_message_template

        company_id = str(settings.get("selected_company_id", "") or "").strip()
        excel_path = Path(
            str(get_company_email_excel_file(settings, company_id) or "")
        ).expanduser()
        subject_template = str(subject or "").strip()
        body_template = str(body or "")

        if not company_id:
            raise ValueError("Bitte ein Unternehmen auswählen.")
        if not excel_path.is_file():
            raise ValueError("Für dieses Unternehmen ist keine gültige Excel-Datei hinterlegt.")
        if not subject_template:
            raise ValueError("Bitte einen Betreff eingeben.")
        if not body_template.strip():
            raise ValueError("Bitte eine Nachricht eingeben.")

        recipients = load_mass_message_rows(excel_path)
        if not recipients:
            raise ValueError("In der Excel-Datei wurden keine E-Mail-Adressen gefunden.")
        invalid = [row for row in recipients if not row.get("EmailValidationSendable")]
        if invalid:
            counts: dict[str, int] = {}
            for row in invalid:
                label = str(row.get("EmailValidationLabel") or "Ungültige E-Mail")
                counts[label] = counts.get(label, 0) + 1
            details = ", ".join(f"{label}: {count}" for label, count in sorted(counts.items()))
            raise ValueError(
                f"Massennachricht ist blockiert: {len(invalid)} ungültige oder doppelte E-Mail-Adresse(n) "
                f"({details}). Bitte Excel-Datei korrigieren und Vorschau neu laden."
            )

        sample_persnr = str(recipients[0].get("PersNr", "") or "")
        context = build_mail_context(settings, sample_persnr, company_id=company_id)
        subject_preview = format_message_template(subject_template, context)
        body_preview = format_message_template(body_template, context)

        return {
            "ready": True,
            "company_id": company_id,
            "company_name": str(context.get("company_name", "") or get_company_name(settings, company_id)),
            "excel_path": str(excel_path),
            "subject_preview": subject_preview,
            "body_preview": body_preview,
            "total_count": len(recipients),
            "recipients": recipients,
            "rows": recipients,
        }

    def _emit_shipping_payload(self, settings: dict) -> str:
        self._persist_workflow_session(settings)
        serialized = json.dumps(self._shipping_payload(settings), ensure_ascii=False)
        self.shippingStateChanged.emit(serialized)
        return serialized

    @Slot(str)
    def _on_processing_progress(self, message: str) -> None:
        settings = load_settings()
        if (
            self._processing_company_id != self._active_company_id(settings)
            or self._processing_input_signature != self._input_signature(settings)
        ):
            return
        self._processing_status["message"] = message
        self._processing_status["progress"] = min(92, int(self._processing_status.get("progress", 8)) + 14)
        self._processing_status["current_step"] = "Prüfung läuft"
        serialized = self._emit_processing_payload(settings)
        self.processingProgress.emit(serialized)

    @Slot(object)
    def _on_shipping_progress(self, message: object) -> None:
        settings = self._settings_with_company_mail(load_settings())
        if (
            self._shipping_company_id != self._active_company_id(settings)
            or self._shipping_input_signature != self._shipping_signature(settings)
        ):
            return
        if isinstance(message, dict) and message.get("kind") == "shipping_progress":
            live_progress = dict(message)
            current = max(0, int(live_progress.get("current", 0) or 0))
            total = max(0, int(live_progress.get("total", 0) or 0))
            phase = str(live_progress.get("phase", "preparing") or "preparing")
            operation = str(live_progress.get("operation", "") or "")
            self._shipping_status["live_progress"] = live_progress
            self._shipping_status["message"] = operation
            self._shipping_status["progress"] = min(99, round((current / total) * 100)) if total else 0
            self._shipping_status["current_step"] = "Versand wird vorbereitet" if phase == "preparing" else "E-Mails werden gesendet"
        else:
            self._shipping_status["message"] = str(message or "")
        serialized = self._emit_shipping_payload(settings)
        self.shippingProgress.emit(serialized)

    @Slot(str)
    def _on_mass_message_progress(self, message: str) -> None:
        self._mass_message_status["message"] = message
        self._mass_message_status["progress"] = min(92, int(self._mass_message_status.get("progress", 8)) + 8)
        self._mass_message_status["current_step"] = "Nachricht wird gesendet"
        serialized = self._emit_mass_message_payload(self._settings_with_company_mail(load_settings()))
        self.massMessageProgress.emit(serialized)

    @Slot(dict)
    def _on_processing_finished(self, result: dict) -> None:
        settings = load_settings()
        if (
            self._processing_company_id != self._active_company_id(settings)
            or self._processing_input_signature != self._input_signature(settings)
        ):
            self._processing_running = False
            self._processing_status = self._idle_processing_status()
            self._processing_input_signature = None
            return
        summary = result.get("summary", {}) if isinstance(result, dict) else {}
        table_rows = result.get("table_rows", []) if isinstance(result, dict) else []
        employees_total = int(summary.get("unique_persnr_count", len(table_rows)) or 0)
        missing_email = int(summary.get("missing_email_count", 0) or 0)
        missing_files = int(summary.get("missing_files_count", 0) or 0)
        invalid_pdf = int(summary.get("invalid_pdf_files", 0) or 0)
        unreadable_pdf = int(summary.get("unreadable_pdf_files", 0) or 0)

        self._processing_running = False
        self._processing_status = {
            **self._idle_processing_status(),
            "finished": True,
            "can_check": True,
            "current_step": "Prüfung abgeschlossen",
            "progress": 100,
            "employees_total": employees_total,
            "processed": len(table_rows),
            "sent": 0,
            "warnings": missing_email + missing_files,
            "missing_email": missing_email,
            "missing_files": missing_files,
            "errors": invalid_pdf + unreadable_pdf,
            "elapsed": "--:--:--",
            "remaining": "00:00:00",
            "message": "Prüfung abgeschlossen. Ergebnisse wurden erstellt.",
            "reports": {
                "audit_path": str(result.get("audit_path") or ""),
                "missing_pdf_path": str(result.get("missing_pdf_path") or ""),
                "run_dir": str(result.get("run_dir") or ""),
            },
        }
        self._validation_company_id = self._processing_company_id
        self._validation_input_signature = self._processing_input_signature
        self._validation_state = self._build_validation_state(result, settings)
        self._register_result_reports(result, settings, "Prüfung")
        self._shipping_company_id = ""
        self._shipping_input_signature = None
        self._shipping_status = self._idle_shipping_status()
        self._shipping_rows = []
        self._shipping_source_rows = []
        serialized = self._emit_processing_payload(settings)
        self.processingFinished.emit(serialized)

    @Slot(dict)
    def _on_shipping_finished(self, result: dict) -> None:
        settings = self._settings_with_company_mail(load_settings())
        if (
            self._shipping_company_id != self._active_company_id(settings)
            or self._shipping_input_signature != self._shipping_signature(settings)
        ):
            self._shipping_running = False
            self._shipping_status = self._idle_shipping_status()
            self._shipping_input_signature = None
            self._shipping_rows = []
            self._shipping_source_rows = []
            return
        summary = result.get("summary", {}) if isinstance(result, dict) else {}
        table_rows = result.get("table_rows", []) if isinstance(result, dict) else []
        dry_run = bool(summary.get("dry_run", True))
        completed_count = int(summary.get("prepared_or_sent_count", 0) or 0)
        if not dry_run and self._shipping_source_rows:
            source_rows = [row for row in self._shipping_source_rows if isinstance(row, dict)]
            source_persnr = {str(row.get("PersNr", "") or "").strip() for row in source_rows}
            summary = {
                **summary,
                "unique_persnr_count": max(
                    int(summary.get("unique_persnr_count", 0) or 0),
                    len(source_persnr - {""}),
                ),
                "missing_email_count": sum(
                    1 for row in source_rows if str(row.get("Status", "") or "") == "Keine E-Mail"
                ),
            }
            result = {**result, "summary": summary}
        self._shipping_running = False
        self._shipping_source_rows = [row for row in table_rows if isinstance(row, dict)]
        self._shipping_rows = [self._shipping_row(row) for row in table_rows if isinstance(row, dict)]
        failed_count = int(summary.get("failed_count", 0) or 0)
        if dry_run:
            current_step = "Dry-Run abgeschlossen"
            message = "Versand-Dry-Run abgeschlossen. Anhänge und Bericht wurden erstellt."
            finished = True
            failed = False
        elif failed_count and completed_count:
            current_step = "Versand teilweise abgeschlossen"
            message = f"{completed_count} E-Mails wurden gesendet, {failed_count} konnten nicht gesendet werden."
            finished = True
            failed = False
        elif failed_count:
            current_step = "Versand fehlgeschlagen"
            message = f"Keine E-Mail wurde gesendet. {failed_count} Versandfehler. Bitte Fehlerdetails prüfen."
            finished = False
            failed = True
        else:
            current_step = "Versand abgeschlossen"
            message = f"Versand abgeschlossen. {completed_count} E-Mails wurden gesendet."
            finished = True
            failed = False
        self._shipping_status = {
            **self._idle_shipping_status(),
            "finished": finished,
            "failed": failed,
            "can_send": True,
            "current_step": current_step,
            "progress": 100,
            "dry_run": dry_run,
            "prepared": completed_count if dry_run else 0,
            "sent": 0 if dry_run else completed_count,
            "skipped": int(summary.get("skipped_count", 0) or 0),
            "errors": failed_count,
            "message": message,
            "reports": {
                "send_report_path": str(result.get("send_report_path") or ""),
                "run_dir": str(result.get("run_dir") or ""),
            },
        }
        self._register_result_reports(result, settings, "Versand")
        serialized = self._emit_shipping_payload(settings)
        self.shippingFinished.emit(serialized)

    @Slot(dict)
    def _on_mass_message_finished(self, result: dict) -> None:
        sent_count = int(result.get("sent_count", 0) or 0)
        error_count = int(result.get("error_count", 0) or 0)
        total_count = int(result.get("total_count", 0) or 0)
        self._mass_message_running = False
        self._mass_message_status = {
            **self._idle_mass_message_status(),
            "finished": True,
            "preview_ready": True,
            "current_step": "Nachricht abgeschlossen",
            "progress": 100,
            "sent_count": sent_count,
            "error_count": error_count,
            "total_count": total_count,
            "errors": result.get("errors", []) if isinstance(result.get("errors", []), list) else [],
            "message": f"Nachricht-Versand abgeschlossen: {sent_count}/{total_count} gesendet, {error_count} Fehler.",
        }
        serialized = self._emit_mass_message_payload(self._settings_with_company_mail(load_settings()))
        self.massMessageFinished.emit(serialized)

    @Slot(str)
    def _on_processing_error(self, message: str) -> None:
        settings = load_settings()
        if (
            self._processing_company_id != self._active_company_id(settings)
            or self._processing_input_signature != self._input_signature(settings)
        ):
            self._processing_running = False
            self._processing_status = self._idle_processing_status()
            self._processing_input_signature = None
            return
        self._processing_running = False
        self._processing_status = {
            **self._idle_processing_status(),
            "failed": True,
            "can_check": True,
            "current_step": "Fehler",
            "progress": 0,
            "errors": 1,
            "message": f"Prüfung fehlgeschlagen: {message}",
        }
        serialized = self._emit_processing_payload(settings)
        self.processingError.emit(serialized)

    @Slot(str)
    def _on_shipping_error(self, message: str) -> None:
        settings = self._settings_with_company_mail(load_settings())
        if (
            self._shipping_company_id != self._active_company_id(settings)
            or self._shipping_input_signature != self._shipping_signature(settings)
        ):
            self._shipping_running = False
            self._shipping_status = self._idle_shipping_status()
            self._shipping_input_signature = None
            return
        self._shipping_running = False
        self._shipping_status = {
            **self._idle_shipping_status(),
            "failed": True,
            "can_send": True,
            "current_step": "Fehler",
            "progress": 0,
            "errors": 1,
            "message": f"Versand fehlgeschlagen: {message}",
        }
        serialized = self._emit_shipping_payload(settings)
        self.shippingError.emit(serialized)

    @Slot(str)
    def _on_mass_message_error(self, message: str) -> None:
        self._mass_message_running = False
        self._mass_message_status = {
            **self._idle_mass_message_status(),
            "failed": True,
            "preview_ready": bool(self._mass_message_preview.get("ready")),
            "current_step": "Fehler",
            "progress": 0,
            "error_count": 1,
            "message": f"Nachricht-Versand fehlgeschlagen: {message}",
        }
        serialized = self._emit_mass_message_payload(self._settings_with_company_mail(load_settings()))
        self.massMessageError.emit(serialized)

    @Slot()
    def _cleanup_worker(self) -> None:
        if self.worker is not None:
            self.worker.deleteLater()
        self.worker = None
        self.worker_thread = None

    @Slot()
    def _cleanup_update_worker(self) -> None:
        if self._update_worker is not None:
            self._update_worker.deleteLater()
        self._update_worker = None
        self._update_thread = None

    @staticmethod
    def _idle_processing_status() -> dict:
        return {
            "running": False,
            "finished": False,
            "failed": False,
            "can_check": False,
            "current_step": "Eingaben prüfen",
            "progress": 0,
            "employees_total": 0,
            "processed": 0,
            "sent": 0,
            "warnings": 0,
            "missing_email": 0,
            "missing_files": 0,
            "errors": 0,
            "elapsed": "00:00:00",
            "remaining": "--:--:--",
            "message": "Eingaben werden geladen.",
        }

    @staticmethod
    def _idle_shipping_status() -> dict:
        return {
            "running": False,
            "finished": False,
            "failed": False,
            "can_send": False,
            "current_step": "Eingaben prüfen",
            "progress": 0,
            "prepared": 0,
            "sent": 0,
            "skipped": 0,
            "errors": 0,
            "live_progress": {},
            "message": "Versanddaten werden geladen.",
        }

    @staticmethod
    def _idle_mass_message_status() -> dict:
        return {
            "running": False,
            "finished": False,
            "failed": False,
            "preview_ready": False,
            "current_step": "Bereit",
            "progress": 0,
            "sent_count": 0,
            "error_count": 0,
            "total_count": 0,
            "errors": [],
            "message": "Nachricht kann vorbereitet werden.",
        }

    @staticmethod
    def _empty_mass_message_preview() -> dict:
        return {
            "ready": False,
            "company_id": "",
            "company_name": "",
            "excel_path": "",
            "subject_preview": "",
            "body_preview": "",
            "total_count": 0,
            "recipients": [],
            "rows": [],
        }

    def _empty_validation_state(self) -> dict:
        return {
            "ready": False,
            "company": {"id": "", "name": ""},
            "summary": {
                "critical": 0,
                "warnings": 0,
                "info": 0,
                "checked": 0,
                "total": 0,
                "status": "Nicht gestartet",
                "updated": "--",
            },
            "filters": {
                "all": 0,
                "critical": 0,
                "warnings": 0,
                "info": 0,
            },
            "rows": [],
            "detail": None,
            "reports": {
                "audit": self._empty_report_state("audit_check.xlsx"),
                "missing": self._empty_report_state("ohne_email_gesamt.pdf"),
            },
        }

    def _build_validation_state(self, result: dict, settings: dict) -> dict:
        summary = result.get("summary", {}) if isinstance(result, dict) else {}
        table_rows = result.get("table_rows", []) if isinstance(result, dict) else []
        validation_rows = [self._validation_row(row) for row in table_rows if isinstance(row, dict)]
        critical = sum(1 for row in validation_rows if row["severity"] == "critical")
        warnings = sum(1 for row in validation_rows if row["severity"] == "warning")
        info = sum(1 for row in validation_rows if row["severity"] == "info")
        checked = int(summary.get("unique_persnr_count", len(table_rows)) or 0)
        total = max(checked, len(table_rows))
        updated = datetime.now().strftime("%d.%m.%Y %H:%M")

        return {
            "ready": True,
            "company": {
                "id": self._validation_company_id,
                "name": get_company_name(settings, self._validation_company_id),
            },
            "summary": {
                "critical": critical,
                "warnings": warnings,
                "info": info,
                "checked": checked,
                "total": total,
                "status": "Abgeschlossen",
                "updated": updated,
            },
            "filters": {
                "all": len(validation_rows),
                "critical": critical,
                "warnings": warnings,
                "info": info,
            },
            "rows": validation_rows,
            "detail": validation_rows[0] if validation_rows else None,
            "reports": {
                "audit": self._report_from_result(result, "audit_path", "audit_check.xlsx"),
                "missing": self._report_from_result(result, "missing_pdf_path", "ohne_email_gesamt.pdf"),
            },
        }

    @staticmethod
    def _validation_row(row: dict) -> dict:
        status = str(row.get("Status", "") or "OK")
        error = str(row.get("Error", "") or "").strip()
        persnr = str(row.get("PersNr", "") or "")
        name = " ".join(
            part for part in [
                str(row.get("Vorname", "") or "").strip(),
                str(row.get("Name", "") or "").strip(),
            ]
            if part
        ).strip() or "-"
        files = str(row.get("Files", "") or "").strip()

        if status == "Fehler" or error:
            severity = "critical"
            category = "PDF"
            description = error or "PDF-Datei konnte nicht validiert werden."
        elif status == "Keine Dateien":
            severity = "critical"
            category = "Dateien"
            description = "Für diesen Mitarbeiter wurde keine passende PDF-Datei gefunden."
        elif status == "Keine E-Mail":
            severity = "warning"
            category = "E-Mail"
            description = "Für diesen Mitarbeiter fehlt eine E-Mail-Adresse."
        elif status in {
            "Doppelte E-Mail",
            "Ungültige E-Mail",
            "Ungültige Zeichen",
            "Ungültiges Format",
            "Domain nicht gefunden",
            "Keine MX-Einträge",
        }:
            severity = "warning"
            category = "E-Mail"
            description = str(row.get("EmailValidationHint", "") or "Die E-Mail-Adresse ist nicht versandfähig.")
        else:
            severity = "success"
            category = "OK"
            description = "Keine Auffälligkeiten."

        return {
            "severity": severity,
            "status": status,
            "employee": name,
            "persnr": persnr,
            "category": category,
            "description": description,
            "document": files or "-",
            "position": "-",
            "email": str(row.get("Email", "") or ""),
            "count": int(row.get("Count", 0) or 0),
            "pages": int(row.get("Pages", 0) or 0),
        }

    @staticmethod
    def _shipping_row(row: dict) -> dict:
        persnr = str(row.get("PersNr", "") or "")
        first_name = str(row.get("Vorname", "") or "").strip()
        last_name = str(row.get("Name", "") or "").strip()
        name = " ".join(part for part in [first_name, last_name] if part).strip() or "-"
        status = str(row.get("Status", "") or "Bereit").strip() or "Bereit"
        attachment = str(row.get("Attachment", "") or "").strip()
        files = str(row.get("Files", "") or "").strip()
        document = attachment or files or "-"
        initials = "".join(part[:1].upper() for part in [first_name, last_name] if part)[:2] or "MA"
        return {
            "employee": name,
            "persnr": persnr,
            "initials": initials,
            "email": str(row.get("Email", "") or ""),
            "document": document,
            "size": "-",
            "status": status,
            "planned": "Dry-Run",
            "error": str(row.get("Error", "") or ""),
        }

    def _shipping_rows_from_validation(self) -> list[dict]:
        rows = []
        for row in self._validation_state.get("rows", []):
            if not isinstance(row, dict):
                continue
            status = str(row.get("status", "") or "")
            if status == "OK":
                status = "Bereit"
            rows.append(
                {
                    "employee": row.get("employee", "-"),
                    "persnr": row.get("persnr", ""),
                    "initials": self._initials(str(row.get("employee", "") or "")),
                    "email": row.get("email", ""),
                    "document": row.get("document", "-"),
                    "size": "-",
                    "status": status,
                    "planned": "Dry-Run",
                    "error": "",
                }
            )
        return rows

    def _inputs_ready(self, settings: dict) -> bool:
        ui_settings = settings.get("ui", {})
        company_id = self._active_company_id(settings)
        pdf_input = str(ui_settings.get("last_pdf_dir", "") or "").strip()
        excel_file = str(get_company_email_excel_file(settings, company_id) or "").strip()
        pdf_expected = "pdf" if self._pdf_input_mode(settings) == "single_pdf" else "folder"
        return bool(
            self._path_state(pdf_input, expected=pdf_expected)["valid"]
            and self._path_state(excel_file, expected="excel")["valid"]
            and self._path_state(str(company_output_dir(settings)), expected="folder")["valid"]
        )

    @staticmethod
    def _initials(name: str) -> str:
        parts = [part for part in name.replace("-", " ").split() if part]
        return "".join(part[:1].upper() for part in parts[:2]) or "MA"

    @staticmethod
    def _normalize_company_id(value: str) -> str:
        normalized = []
        previous_dash = False
        for char in str(value or "").strip().lower():
            if char.isascii() and char.isalnum():
                normalized.append(char)
                previous_dash = False
            elif char in {"_", "-"} or char.isspace():
                if normalized and not previous_dash:
                    normalized.append("-")
                    previous_dash = True
        return "".join(normalized).strip("-")

    @staticmethod
    def _pdf_input_mode(settings: dict) -> str:
        mode = str(settings.get("ui", {}).get("last_pdf_input_mode", "folder") or "folder").strip()
        return mode if mode in {"folder", "single_pdf"} else "folder"

    @staticmethod
    def _set_company_excel_file(settings: dict, excel_file: str) -> None:
        selected_company_id = str(settings.get("selected_company_id", "") or "").strip()
        companies = settings.setdefault("companies", [])
        if isinstance(companies, list):
            for company in companies:
                if not isinstance(company, dict):
                    continue
                if str(company.get("id", "") or "").strip() == selected_company_id:
                    company["email_excel_file"] = excel_file
                    return

    @staticmethod
    def _set_company_pdf_input(
        settings: dict,
        pdf_input: str | None = None,
        mode: str | None = None,
    ) -> None:
        selected_company_id = str(settings.get("selected_company_id", "") or "").strip()
        for company in settings.get("companies", []):
            if not isinstance(company, dict):
                continue
            if str(company.get("id", "") or "").strip() != selected_company_id:
                continue
            if pdf_input is not None:
                company["pdf_input"] = str(pdf_input or "").strip()
            if mode is not None:
                resolved_mode = str(mode or "folder").strip()
                company["pdf_input_mode"] = resolved_mode if resolved_mode in {"folder", "single_pdf"} else "folder"
            return

    def _store_active_company_pdf(self, settings: dict) -> None:
        ui_settings = settings.get("ui", {})
        self._set_company_pdf_input(
            settings,
            str(ui_settings.get("last_pdf_dir", "") or ""),
            str(ui_settings.get("last_pdf_input_mode", "folder") or "folder"),
        )

    @staticmethod
    def _load_active_company_pdf(settings: dict) -> None:
        selected_company_id = str(settings.get("selected_company_id", "") or "").strip()
        ui_settings = settings.setdefault("ui", {})
        for company in settings.get("companies", []):
            if not isinstance(company, dict):
                continue
            if str(company.get("id", "") or "").strip() != selected_company_id:
                continue
            ui_settings["last_pdf_dir"] = str(company.get("pdf_input", "") or "")
            mode = str(company.get("pdf_input_mode", "folder") or "folder")
            ui_settings["last_pdf_input_mode"] = mode if mode in {"folder", "single_pdf"} else "folder"
            return
        ui_settings["last_pdf_dir"] = ""
        ui_settings["last_pdf_input_mode"] = "folder"

    def _activate_dialog_parent(self) -> None:
        if self._dialog_parent is None:
            return
        self._dialog_parent.raise_()
        self._dialog_parent.activateWindow()

    @staticmethod
    def _dialog_start_path(raw_path: str) -> str:
        if not raw_path:
            return str(BASE_DIR.parent if BASE_DIR.name.casefold() == "app" else BASE_DIR)
        path = Path(raw_path).expanduser()
        if path.is_file():
            return str(path.parent)
        if path.is_dir():
            return str(path)
        for parent in path.parents:
            if parent.exists() and parent.is_dir():
                return str(parent)
        return str(BASE_DIR.parent if BASE_DIR.name.casefold() == "app" else BASE_DIR)

    @staticmethod
    def _empty_report_state(filename: str) -> dict[str, str | bool]:
        return {"name": filename, "exists": False, "label": "Nicht erstellt", "path": ""}

    @staticmethod
    def _safe_report_source_name(value: str) -> str:
        safe = "".join(ch if ch.isalnum() or ch in ("-", "_") else "_" for ch in str(value or "").strip())
        return safe.strip("_") or "PDF_Ordner"

    @staticmethod
    def _report_kind_for_path(path: Path) -> str:
        for kind, filename in WebBridge.REPORT_FILES.items():
            if path.name.lower() == filename.lower():
                return kind
        return "other"

    @staticmethod
    def _report_type_for_path(path: Path) -> str:
        suffix = path.suffix.lower().lstrip(".")
        return "xlsx" if suffix in {"xlsx", "xls"} else (suffix or "file")

    @staticmethod
    def _report_timestamp(path: Path) -> str:
        try:
            return datetime.fromtimestamp(path.stat().st_mtime).astimezone().isoformat(timespec="seconds")
        except OSError:
            return ""

    @staticmethod
    def _report_size(path: Path) -> int:
        try:
            return int(path.stat().st_size)
        except OSError:
            return 0

    @staticmethod
    def _report_id(company_id: str, path: Path) -> str:
        raw = f"{company_id}|{path.expanduser().absolute()}".encode("utf-8", errors="ignore")
        return hashlib.sha256(raw).hexdigest()[:20]

    @staticmethod
    def _empty_report_metrics() -> dict[str, int]:
        return {
            "employees": 0,
            "missing_email": 0,
            "processed": 0,
            "warnings": 0,
            "errors": 0,
            "sent": 0,
            "delivered": 0,
            "failed": 0,
            "prepared": 0,
        }

    def _is_report_path_safe(self, path: Path) -> bool:
        try:
            resolved = path.expanduser().resolve()
            roots = [COMPANIES_DIR.resolve(), LEGACY_GESOB_DIR.resolve()]
            return any(resolved.is_relative_to(root) for root in roots) and resolved.name in set(self.REPORT_FILES.values())
        except (OSError, RuntimeError, ValueError):
            return False

    def _load_report_index(self) -> list[dict]:
        stored_records: list[dict] = []
        if self._report_history is not None:
            try:
                stored_records = self._report_history.load_records()
            except Exception:
                stored_records = []

        legacy_records: list[dict] = []
        if self.REPORT_INDEX_PATH.is_file():
            try:
                data = json.loads(self.REPORT_INDEX_PATH.read_text(encoding="utf-8"))
                raw_records = data.get("records", []) if isinstance(data, dict) else []
                legacy_records = [item for item in raw_records if isinstance(item, dict)]
            except (OSError, json.JSONDecodeError):
                legacy_records = []

        merged: dict[str, dict] = {}
        for index, record in enumerate(legacy_records):
            key = str(record.get("id") or f"legacy-{index}")
            merged[key] = record
        for index, record in enumerate(stored_records):
            key = str(record.get("id") or f"stored-{index}")
            merged[key] = record
        records = list(merged.values())
        if records and self._report_history is not None:
            try:
                self._report_history.upsert_records(records)
            except Exception:
                pass
        return records

    def _save_report_index(self, records: list[dict]) -> None:
        if self._report_history is not None:
            try:
                self._report_history.upsert_records(records)
            except Exception:
                pass
        self.REPORT_INDEX_PATH.parent.mkdir(parents=True, exist_ok=True)
        payload = {"version": 1, "updated_at": datetime.now().astimezone().isoformat(timespec="seconds"), "records": records}
        temporary = self.REPORT_INDEX_PATH.with_suffix(".tmp")
        temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.replace(self.REPORT_INDEX_PATH)

    def _report_record(
        self,
        path: Path,
        company_id: str,
        company_name: str,
        *,
        run_id: str = "",
        operation: str = "Importiert",
        source: str = "folder",
        metrics: dict | None = None,
        dry_run: bool | None = None,
    ) -> dict:
        path = path.expanduser().absolute()
        exists = path.is_file()
        kind = self._report_kind_for_path(path)
        titles = {
            "audit": "Prüfbericht",
            "missing": "PDF ohne E-Mail",
            "send": "Versandbericht",
            "other": path.stem,
        }
        return {
            "id": self._report_id(company_id, path),
            "company_id": company_id,
            "company_name": company_name,
            "run_id": run_id or path.parent.name,
            "run_dir": str(path.parent),
            "kind": kind,
            "type": self._report_type_for_path(path),
            "title": titles.get(kind, path.stem),
            "filename": path.name,
            "subtitle": operation,
            "operation": operation,
            "path": str(path),
            "exists": exists,
            "status": "ready" if exists else "missing",
            "created_at": self._report_timestamp(path),
            "size": self._report_size(path),
            "owner": "LohnMail",
            "source": source,
            "dry_run": dry_run,
            "metrics": {**self._empty_report_metrics(), **(metrics or {})},
        }

    def _legacy_run_matches_company(self, run_dir: Path, settings: dict) -> bool:
        ui_settings = settings.get("ui", {}) if isinstance(settings, dict) else {}
        raw_pdf_input = str(ui_settings.get("last_pdf_dir", "") or "").strip()
        if not raw_pdf_input:
            return False
        pdf_input = Path(raw_pdf_input).expanduser()
        source_name = self._safe_report_source_name(pdf_input.name)
        match = re.match(r"^\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}_(?:check_)?(.+)$", run_dir.name)
        return bool(match and match.group(1) == source_name)

    def _discover_report_records(self, settings: dict, records: list[dict]) -> tuple[list[dict], bool]:
        company_id = self._active_company_id(settings)
        if not company_id:
            return records, False
        company_name = get_company_name(settings, company_id)
        companies = [item for item in settings.get("companies", []) if isinstance(item, dict)]
        indexed_paths = {str(Path(str(item.get("path", "") or "")).expanduser().absolute()) for item in records}
        changed = False

        report_roots = [company_output_dir(settings, company_id), LEGACY_GESOB_DIR]
        for filename in self.REPORT_FILES.values():
            for root in report_roots:
                for path in root.glob(f"*/{filename}"):
                    absolute = str(path.expanduser().absolute())
                    if absolute in indexed_paths or not path.is_file():
                        continue
                    if (
                        root == LEGACY_GESOB_DIR
                        and len(companies) > 1
                        and not self._legacy_run_matches_company(path.parent, settings)
                    ):
                        continue
                    operation = "Versand" if path.name == "send_report.xlsx" else "Prüfung"
                    records.append(
                        self._report_record(
                            path,
                            company_id,
                            company_name,
                            operation=operation,
                            source="folder",
                        )
                    )
                    indexed_paths.add(absolute)
                    changed = True
        return records, changed

    def _register_result_reports(self, result: dict, settings: dict, operation: str) -> None:
        company_id = self._active_company_id(settings)
        if not company_id or not isinstance(result, dict):
            return
        company_name = get_company_name(settings, company_id)
        summary = result.get("summary", {}) if isinstance(result.get("summary"), dict) else {}
        table_rows = result.get("table_rows", []) if isinstance(result.get("table_rows"), list) else []
        dry_run = bool(summary.get("dry_run", False))
        sent = 0 if dry_run else int(summary.get("prepared_or_sent_count", 0) or 0)
        failed = int(summary.get("failed_count", 0) or 0)
        metrics = {
            "employees": int(summary.get("unique_persnr_count", len(table_rows)) or 0),
            "missing_email": int(summary.get("missing_email_count", 0) or 0),
            "processed": len(table_rows),
            "warnings": int(summary.get("missing_email_count", 0) or 0) + int(summary.get("missing_files_count", 0) or 0),
            "errors": int(summary.get("invalid_pdf_files", 0) or 0) + int(summary.get("unreadable_pdf_files", 0) or 0) + failed,
            "sent": sent,
            "delivered": max(0, sent - failed),
            "failed": failed,
            "prepared": int(summary.get("prepared_or_sent_count", 0) or 0) if dry_run else 0,
        }
        run_id = str(result.get("run_id", "") or "")
        candidates = {
            "audit_path": result.get("audit_path"),
            "missing_pdf_path": result.get("missing_pdf_path"),
            "send_report_path": result.get("send_report_path"),
        }
        records = self._load_report_index()
        by_id = {str(item.get("id", "") or ""): item for item in records}
        registered_records: list[dict] = []
        for raw_path in candidates.values():
            path = Path(str(raw_path or "")).expanduser()
            if not path.is_file() or not self._is_report_path_safe(path):
                continue
            record = self._report_record(
                path,
                company_id,
                company_name,
                run_id=run_id,
                operation=operation,
                source="workflow",
                metrics=metrics,
                dry_run=dry_run if operation == "Versand" else None,
            )
            by_id[record["id"]] = record
            registered_records.append(record)
        self._save_report_index(list(by_id.values()))
        if operation == "Versand" and registered_records:
            self._report_sessions(registered_records, company_id)

    @staticmethod
    def _email_validation_code(label: str) -> str:
        normalized = str(label or "").strip().lower()
        mapping = {
            "gültig": "valid",
            "fehlt": "missing",
            "keine e-mail": "missing",
            "ungültiges format": "invalid_format",
            "ungültige zeichen": "illegal_characters",
            "unzulässige zeichen": "illegal_characters",
            "doppelte adresse": "duplicate",
            "doppelte e-mail": "duplicate",
            "domain nicht gefunden": "domain_missing",
            "keine mx-einträge": "mx_missing",
            "keine mx-record": "mx_missing",
            "dns nicht geprüft": "dns_unavailable",
            "dns-prüfung nicht verfügbar": "dns_unavailable",
        }
        return mapping.get(normalized, "not_checked")

    def _read_send_report_rows(self, path: Path) -> list[dict]:
        if not path.is_file():
            return []
        try:
            workbook = load_workbook(path, read_only=True, data_only=True)
            sheet = workbook.active
            values = sheet.iter_rows(values_only=True)
            headers = [str(value or "").strip() for value in next(values, ())]
            rows: list[dict] = []
            for raw_values in values:
                source = {
                    headers[index]: raw_values[index]
                    for index in range(min(len(headers), len(raw_values)))
                    if headers[index]
                }
                persnr = str(source.get("PersNr") or "").strip()
                if not persnr:
                    continue
                employee = str(source.get("Name, Vorname") or "").strip()
                if not employee:
                    first_name = str(source.get("Vorname") or "").strip()
                    last_name = str(source.get("Name") or "").strip()
                    employee = " ".join(part for part in (first_name, last_name) if part).strip()
                employee = employee or "-"
                validation_label = (
                    str(source.get("E-Mail-Prüfung") or "").strip()
                    or "Keine Prüfdaten (alter Bericht)"
                )
                sendable_value = str(source.get("Versandfähig") or "").strip().lower()
                sendable = sendable_value in {"ja", "yes", "true", "1"}
                status = str(source.get("Status") or "").strip() or "Unbekannt"
                rows.append(
                    {
                        "persnr": persnr,
                        "employee": employee,
                        "email": str(source.get("Email") or "").strip(),
                        "document": str(source.get("Anhang") or source.get("Dateien") or "").strip(),
                        "status": status,
                        "error": str(source.get("Fehler") or "").strip(),
                        "email_validation": {
                            "code": self._email_validation_code(validation_label),
                            "label": validation_label,
                            "mx_status": str(source.get("MX") or "-").strip() or "-",
                            "checked_at": str(source.get("Geprüft am") or "").strip(),
                            "sendable": sendable,
                            "hint": str(source.get("Prüfhinweis") or "").strip(),
                        },
                    }
                )
            workbook.close()
            return rows
        except Exception:
            return []

    def _report_sessions(self, records: list[dict], company_id: str = "") -> list[dict]:
        grouped: dict[str, list[dict]] = {}
        for record in records:
            run_id = str(record.get("run_id") or record.get("id") or "").strip()
            grouped.setdefault(run_id, []).append(record)

        sessions: list[dict] = []
        for run_id, run_records in grouped.items():
            send_record = next(
                (
                    record
                    for record in run_records
                    if record.get("kind") == "send"
                ),
                None,
            )
            if not send_record:
                continue
            metrics = self._empty_report_metrics()
            for record in run_records:
                raw_metrics = record.get("metrics", {}) if isinstance(record.get("metrics"), dict) else {}
                for key in metrics:
                    metrics[key] = max(metrics[key], int(raw_metrics.get(key, 0) or 0))
            session_company_id = str(send_record.get("company_id") or "")
            recipients = self._read_send_report_rows(Path(str(send_record.get("path") or "")).expanduser())
            if not recipients and self._report_history is not None:
                try:
                    recipients = self._report_history.load_recipients(session_company_id, run_id)
                except Exception:
                    recipients = []
            if recipients:
                metrics["employees"] = max(metrics["employees"], len(recipients))
                metrics["missing_email"] = max(
                    metrics["missing_email"],
                    sum(1 for row in recipients if row.get("status") == "Keine E-Mail"),
                )
                metrics["failed"] = max(
                    metrics["failed"],
                    sum(1 for row in recipients if row.get("status") == "Fehler"),
                )
            dry_run = bool(send_record.get("dry_run"))
            if metrics["failed"]:
                status_key, status_label = "error", "Mit Fehlern"
            elif dry_run:
                status_key, status_label = "prepared", "Vorbereitet"
            elif metrics["sent"]:
                status_key, status_label = "sent", "Versendet"
            else:
                status_key, status_label = "completed", "Abgeschlossen"
            created_at = max(str(record.get("created_at") or "") for record in run_records)
            files = sorted(
                run_records,
                key=lambda record: {"audit": 0, "missing": 1, "send": 2}.get(str(record.get("kind")), 9),
            )
            session = {
                "id": run_id,
                "run_id": run_id,
                "company_id": session_company_id,
                "company_name": str(send_record.get("company_name") or ""),
                "created_at": created_at,
                "status": status_label,
                "status_key": status_key,
                "dry_run": dry_run,
                "metrics": metrics,
                "files": files,
                "recipients": recipients,
            }
            sessions.append(session)
            if self._report_history is not None:
                try:
                    self._report_history.upsert_session(session)
                    saved_recipients = self._report_history.load_recipients(session_company_id, run_id)
                    if saved_recipients:
                        session["recipients"] = saved_recipients
                except Exception:
                    pass

        if self._report_history is not None and company_id:
            try:
                known_run_ids = {str(session.get("run_id") or "") for session in sessions}
                for saved_session in self._report_history.load_sessions(company_id):
                    saved_run_id = str(saved_session.get("run_id") or "")
                    if not saved_run_id or saved_run_id in known_run_ids:
                        continue
                    saved_session["files"] = []
                    sessions.append(saved_session)
                    known_run_ids.add(saved_run_id)
            except Exception:
                pass
        sessions.sort(key=lambda session: str(session.get("created_at") or ""), reverse=True)
        return sessions

    def _reports_payload(self, settings: dict) -> dict:
        company_id = self._active_company_id(settings)
        records = self._load_report_index()
        records, changed = self._discover_report_records(settings, records)
        if changed:
            self._save_report_index(records)

        active_records = []
        for item in records:
            if str(item.get("company_id", "") or "") != company_id:
                continue
            path = Path(str(item.get("path", "") or "")).expanduser()
            normalized = {**item}
            normalized["exists"] = bool(path.is_file() and self._is_report_path_safe(path))
            normalized["status"] = "ready" if normalized["exists"] else "missing"
            normalized["size"] = self._report_size(path) if normalized["exists"] else int(item.get("size", 0) or 0)
            raw_metrics = item.get("metrics", {}) if isinstance(item.get("metrics"), dict) else {}
            normalized["metrics"] = {**self._empty_report_metrics(), **raw_metrics}
            if item.get("operation") == "Versand" and "missing_email" not in raw_metrics:
                normalized["metrics"]["missing_email"] = int(raw_metrics.get("warnings", 0) or 0)
            active_records.append(normalized)
        active_records.sort(key=lambda item: str(item.get("created_at", "") or ""), reverse=True)
        sessions = self._report_sessions(active_records, company_id)
        latest_session = next((session for session in sessions if not session.get("dry_run")), None)
        if latest_session is None and sessions:
            latest_session = sessions[0]

        latest = {}
        for kind in self.REPORT_FILES:
            record = next((item for item in active_records if item.get("kind") == kind and item.get("exists")), None)
            latest[kind] = (
                {
                    "name": record.get("filename", self.REPORT_FILES[kind]),
                    "exists": True,
                    "label": self._format_mtime(Path(str(record.get("path", "") or ""))),
                    "path": record.get("path", ""),
                    "id": record.get("id", ""),
                }
                if record
                else self._empty_report_state(self.REPORT_FILES[kind])
            )
        return {
            "company": {"id": company_id, "name": get_company_name(settings, company_id)},
            "output_dir": str(company_output_dir(settings, company_id)),
            "records": active_records,
            "sessions": sessions,
            "latest_session_id": str((latest_session or {}).get("id") or ""),
            "latest": latest,
            "updated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        }

    def _report_state_from_path(self, raw_path: str, filename: str) -> dict[str, str | bool]:
        path = Path(str(raw_path or "")).expanduser()
        if not path.is_file():
            return self._empty_report_state(filename)
        return {
            "name": filename,
            "exists": True,
            "label": self._format_mtime(path),
            "path": str(path),
        }

    def _current_report_state(
        self,
        filename: str,
        settings: dict,
        reports_payload: dict | None = None,
    ) -> dict[str, str | bool]:
        company_id = self._active_company_id(settings)
        input_signature = self._input_signature(settings)
        shipping_signature = self._shipping_signature(settings)
        if (
            filename in {"audit_check.xlsx", "ohne_email_gesamt.pdf"}
            and self._validation_company_id == company_id
            and self._validation_input_signature == input_signature
        ):
            key = "audit" if filename == "audit_check.xlsx" else "missing"
            report = self._validation_state.get("reports", {}).get(key, {})
            return self._report_state_from_path(str(report.get("path", "") or ""), filename)
        if (
            filename == "send_report.xlsx"
            and self._shipping_company_id == company_id
            and self._shipping_input_signature == shipping_signature
        ):
            raw_path = self._shipping_status.get("reports", {}).get("send_report_path", "")
            return self._report_state_from_path(str(raw_path or ""), filename)
        kind = self._report_kind_for_path(Path(filename))
        archived = (reports_payload or self._reports_payload(settings)).get("latest", {}).get(kind, {})
        if archived.get("exists"):
            return archived
        return self._empty_report_state(filename)

    def _current_reports_state(
        self,
        settings: dict,
        reports_payload: dict | None = None,
    ) -> dict[str, dict[str, str | bool]]:
        return {
            "audit": self._current_report_state("audit_check.xlsx", settings, reports_payload),
            "missing": self._current_report_state("ohne_email_gesamt.pdf", settings, reports_payload),
            "send": self._current_report_state("send_report.xlsx", settings, reports_payload),
        }

    def _dashboard_runs(self, records: list[dict]) -> list[dict]:
        grouped: dict[str, dict] = {}
        for record in records:
            if not isinstance(record, dict) or not record.get("exists"):
                continue
            run_id = str(record.get("run_id", "") or record.get("run_dir", "") or record.get("id", ""))
            if not run_id:
                continue
            current = grouped.setdefault(
                run_id,
                {
                    "id": run_id,
                    "company_id": str(record.get("company_id", "") or ""),
                    "company_name": str(record.get("company_name", "") or ""),
                    "created_at": "",
                    "operation": "Prüfung",
                    "metrics": self._empty_report_metrics(),
                    "reports": [],
                },
            )
            created_at = str(record.get("created_at", "") or "")
            if created_at >= str(current.get("created_at", "") or ""):
                current["created_at"] = created_at
            if str(record.get("operation", "") or "") == "Versand":
                current["operation"] = "Versand"
            metrics = record.get("metrics", {}) if isinstance(record.get("metrics"), dict) else {}
            for key in self._empty_report_metrics():
                current["metrics"][key] = max(
                    int(current["metrics"].get(key, 0) or 0),
                    int(metrics.get(key, 0) or 0),
                )
            current["reports"].append(
                {
                    "kind": str(record.get("kind", "") or ""),
                    "name": str(record.get("filename", "") or ""),
                    "path": str(record.get("path", "") or ""),
                }
            )

        runs = list(grouped.values())
        for run in runs:
            metrics = run["metrics"]
            if int(metrics.get("failed", 0) or metrics.get("errors", 0) or 0) > 0:
                run["status"] = "Fehler"
            elif int(metrics.get("sent", 0) or 0) > 0:
                run["status"] = "Versand abgeschlossen"
            elif int(metrics.get("prepared", 0) or 0) > 0:
                run["status"] = "Versand vorbereitet"
            elif int(metrics.get("warnings", 0) or metrics.get("missing_email", 0) or 0) > 0:
                run["status"] = "Prüfung mit Warnungen"
            else:
                run["status"] = "Prüfung abgeschlossen"
        runs.sort(key=lambda item: str(item.get("created_at", "") or ""), reverse=True)
        return runs

    def _report_from_result(self, result: dict, key: str, filename: str) -> dict[str, str | bool]:
        raw_path = result.get(key) if isinstance(result, dict) else None
        return self._report_state_from_path(str(raw_path or ""), filename)

    def _path_state(self, raw_path: str, expected: str) -> dict[str, str | bool]:
        raw_path = str(raw_path or "").strip()
        if not raw_path:
            return {
                "path": "",
                "label": "Nicht ausgewählt",
                "exists": False,
                "valid": False,
                "expected": expected,
                "updated": "",
            }

        path = Path(raw_path).expanduser()
        exists = path.exists()
        if expected == "folder":
            valid = exists and path.is_dir()
        elif expected == "pdf":
            valid = exists and path.is_file() and path.suffix.lower() == ".pdf"
        elif expected == "excel":
            valid = exists and path.is_file() and path.suffix.lower() in {".xlsx", ".xls", ".xlsm"}
        else:
            valid = exists

        if valid:
            label = "Bereit"
        elif exists:
            label = "Falscher Typ"
        else:
            label = "Nicht gefunden"

        updated = ""
        if exists:
            try:
                updated = self._format_mtime(path)
            except OSError:
                updated = ""

        return {
            "path": str(path),
            "label": label,
            "exists": exists,
            "valid": valid,
            "expected": expected,
            "updated": updated,
        }

    @staticmethod
    def _format_mtime(path: Path) -> str:
        timestamp = datetime.fromtimestamp(path.stat().st_mtime)
        return timestamp.strftime("%d.%m.%Y %H:%M")
