APP_VERSION = "2.0.3"
APP_BUILD = "2026.08.31.3"
# This flag exists only in explicitly labelled test builds. Production builds
# must keep it False so only signed EXE/MSI installers are accepted.
TEST_UPDATES_ENABLED = True
