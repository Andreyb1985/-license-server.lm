$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

if (-not (Test-Path ".venv\Scripts\python.exe")) {
    py -m venv .venv
}

& ".venv\Scripts\python.exe" -m pip install --upgrade pip
& ".venv\Scripts\python.exe" -m pip install -r requirements-build-windows.txt

& ".venv\Scripts\python.exe" -m PyInstaller `
    --noconfirm `
    --clean `
    --windowed `
    --onedir `
    --contents-directory . `
    --name LohnMail `
    --icon "web\assets\brand\LohnMail.ico" `
    --version-file "windows_version_info.txt" `
    --collect-all webview `
    --add-data "web;web" `
    --add-data "settings_template.json;." `
    main.py

$ReleaseRoot = Join-Path $PSScriptRoot "release\LohnMail"
$ReleaseApp = Join-Path $ReleaseRoot "App"
$ReleaseSettings = Join-Path $ReleaseRoot "Settings"
$ReleaseCompanies = Join-Path $ReleaseRoot "Companies"

if (Test-Path $ReleaseRoot) {
    Remove-Item -Recurse -Force $ReleaseRoot
}

New-Item -ItemType Directory -Force $ReleaseApp, $ReleaseSettings, $ReleaseCompanies | Out-Null
Copy-Item -Recurse -Force "dist\LohnMail\*" $ReleaseApp
Copy-Item -Force "settings_template.json" (Join-Path $ReleaseSettings "settings.json")
New-Item -ItemType File -Force (Join-Path $ReleaseCompanies ".gitkeep") | Out-Null

$ForbiddenFiles = @(
    "license.json",
    "machine_id",
    "workflow_sessions.json",
    "lohnmail_history.sqlite3",
    "settings.before-legacy-import.json"
)
foreach ($ForbiddenFile in $ForbiddenFiles) {
    if (Get-ChildItem -Path $ReleaseRoot -Recurse -File -Filter $ForbiddenFile) {
        throw "Unsichere Release-Datei gefunden: $ForbiddenFile"
    }
}

$ReleaseSettingsData = Get-Content (Join-Path $ReleaseSettings "settings.json") -Raw | ConvertFrom-Json
if ($ReleaseSettingsData.companies.Count -ne 0 -or $ReleaseSettingsData.selected_company_id) {
    throw "Release-settings.json enthält Mandantendaten."
}
if ($ReleaseSettingsData.smtp.password) {
    throw "Release-settings.json enthält ein SMTP-Passwort."
}

Write-Host ""
Write-Host "Build fertig: dist\LohnMail\LohnMail.exe" -ForegroundColor Green
Write-Host "Saubere portable Struktur: release\LohnMail" -ForegroundColor Green
