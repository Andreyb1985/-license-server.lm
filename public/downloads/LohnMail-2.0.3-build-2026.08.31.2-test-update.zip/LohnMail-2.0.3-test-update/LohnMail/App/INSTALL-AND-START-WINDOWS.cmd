@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if errorlevel 1 (
    echo Python 3 wurde nicht gefunden.
    echo Bitte Python 3.12 oder 3.13 von https://www.python.org/downloads/windows/ installieren.
    echo Bei der Installation "Add python.exe to PATH" aktivieren.
    goto :error
)

if not exist ".venv\Scripts\python.exe" (
    py -m venv .venv
    if errorlevel 1 goto :error
)

if not exist ".venv\.lohnmail-requirements-2.0.2" (
    ".venv\Scripts\python.exe" -m pip install -r requirements-windows.txt
    if errorlevel 1 goto :error
    > ".venv\.lohnmail-requirements-2.0.2" echo 2.0.2
)

".venv\Scripts\python.exe" main.py
if errorlevel 1 goto :error
exit /b 0

:error
echo.
echo LohnMail konnte nicht gestartet werden. Fehlercode: %errorlevel%
pause
exit /b %errorlevel%
